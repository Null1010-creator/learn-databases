# 读入一个整数列表，输出删除最大元素和最小元素后的列表。最大元素和最小元素可能有多个。

a = eval(input())
b = max(a)
c = min(a)
for i in a:
    if i == b:
        a.remove(i)
for x in a:
    if x == c:
        a.remove(x)
for y in a:
    if y == b:
        a.remove(y)
for z in a:
    if z == c:
        a.remove(z)
print(a)