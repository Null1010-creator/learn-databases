A = map(eval,input().split())
B =list(A)
C = []
for i in range(10):
    a = B.count(i)
    C.append(a)
print(" ".join(str(i) for i in C))


# a = B.count(0)
# b = B.count(1)
# c = B.count(2)
# d = B.count(3)
# e = B.count(4)
# f = B.count(5)
# g = B.count(6)
# h = B.count(7)
# i = B.count(8)
# j = B.count(9)
# print(a,b,c,d,e,f,g,h,i,j)
# 0 2 3 2 1 1 0 0 0 0

# A = map(eval,input().split(" "))
# B =list(A)

# print(type(a))