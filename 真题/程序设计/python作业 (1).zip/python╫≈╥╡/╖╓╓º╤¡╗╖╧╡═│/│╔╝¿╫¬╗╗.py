iGrade = eval(input())
if iGrade>=90:
    print ("A")
elif iGrade>=80 and iGrade<90:
    print("B")
elif iGrade>=70 and iGrade<80:
    print("C")
elif iGrade>=60 and iGrade<70:
    print("D")
else:
    print("E")