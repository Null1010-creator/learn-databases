iLength = eval(input())
iWidth = eval(input())
if iLength<=0 or iWidth<0:
    print("illegal data")
elif iLength==iWidth:
    print("It's a square")
else:
    print("It's a rectangle")