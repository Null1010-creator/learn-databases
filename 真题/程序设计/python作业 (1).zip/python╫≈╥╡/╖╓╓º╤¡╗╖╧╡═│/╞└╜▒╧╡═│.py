iChinese = eval(input())
iMath = eval(input())
if iChinese>=99 and iMath>=99:
    print("You won a scholarship of 500 yuan!")
elif iChinese<30 and iMath<30:
    print("You need to relearn!")
else:
    print("")