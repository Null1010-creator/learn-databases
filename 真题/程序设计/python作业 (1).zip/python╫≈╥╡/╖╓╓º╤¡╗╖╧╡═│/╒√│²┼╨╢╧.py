a = eval(input())
if a%2==0 and a%5!=0:
    print("True")
elif a%2!=0 and a%5==0:
    print("True")
else:
    print("False")