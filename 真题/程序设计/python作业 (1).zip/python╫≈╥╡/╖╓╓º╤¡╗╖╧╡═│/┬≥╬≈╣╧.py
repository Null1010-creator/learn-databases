def main ():
    total_count=int(input ())
    calculate_day(total_count)

def calculate_day(total_count):
    days=1
    while total_count>0:
        total_count = total_count-(int(total_count/2)+2)
        if total_count>0:
            days +=1
        elif total_count<=0:
            break
    print (days)

main ()