a = int(input())
b = int(input())
c = a/b
c = '%.2f'%c
print(c)