sName = input()
a =int(eval(input()))
# int可以将小数点后面的小数去掉
iAge = '%d'%a
print ("My name is", sName, "and I'm", iAge, "years old this year.")