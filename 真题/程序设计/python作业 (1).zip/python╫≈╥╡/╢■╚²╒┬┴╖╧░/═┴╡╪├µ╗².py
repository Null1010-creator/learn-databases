a = int(input())
c = a/43560
c = '%.3f'%c
print("The land area is",c)