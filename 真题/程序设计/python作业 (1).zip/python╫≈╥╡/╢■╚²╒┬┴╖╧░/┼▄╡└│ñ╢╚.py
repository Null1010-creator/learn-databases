sName = input()
a = eval(input())
v = eval(input())
l = v*v/a*0.5
aSpeed = '%.2f'%a
fSpeed = '%.2f'%v
eLength = '%.2f'%l
print ("The acceleration of",sName, "is",aSpeed,"M / s, the take-off speed is",fSpeed,"M / s, and the shortest take-off runway length is",eLength,"M.")
# The acceleration of B350 is 3.57 M / s, the take-off speed is 60.00 M / s, and the shortest take-off runway length is 503.92 M.