MaleStudent=eval(input())
FemaleStudent=eval(input())
MRatio=MaleStudent/(MaleStudent+FemaleStudent)*100
FRatio=FemaleStudent/(MaleStudent+FemaleStudent)*100
sText="The male students ratio is %.2f%%,the female students ratio is %.2f%%"%(MRatio,FRatio)
print(sText)