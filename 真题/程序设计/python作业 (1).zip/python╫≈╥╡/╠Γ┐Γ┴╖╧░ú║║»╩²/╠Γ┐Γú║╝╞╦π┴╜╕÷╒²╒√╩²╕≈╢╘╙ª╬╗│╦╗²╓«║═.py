# 【问题描述】输入两个正整数a,b，计算两个正整数各对应位乘积之和. 例如a=1123，b=405,  输出为19（1*0+1*4+2*0+3*5=19). 
# 如果a,b不是正整数，输出error。

# 【输入形式】一行两个正整数，以1个空格分隔
# 【输出形式】一个正整数或者error
# 【样例输入】1123 405
# 【样例输出】19

# 【样例输入】-1123 405.6
# 【样例输出】error

# 【样例输入】1#123 405
# 【样例输出】error



def myFun(a,b):
    c = 0
    d = len(a)
    e = len(b)
    if d > e:
        for i in range(1,e+1):
            c = c + int(a[-i]) * int(b[-i])
    else:
        for i in range(1,d+1):
            c = c + int(a[-i]) * int(b[-i])
    return c


num=input().split()
a=num[0]
b=num[1]
if  a.isdigit()  and  b.isdigit():  #判断a,b是否都是数字
    print(myFun(a,b))    #调用自定义函数
else:
    print("error")