# 【问题描述】输入一个正整数 n，输出［2,n)范围内素数的个数，以及这些素数的和，2<n<1000
# 【输入形式】一个正整数n,2<n<1000

# 【输出形式】两个整数，第一个数是［2,n)范围内素数个数，第二个是这些素数的和，1个空格分隔
# 【样例输入】5
# 【样例输出】2 5
# 【样例说明】［2，5）范围有2个素数，2和3，它们的和是2+3=5

def prime(n):  #该函数有两个返回值，分别是素数个数和素数的和
    for x in range(3,number):
        a = [2]
        for i in range(2,x//2+1):
            if x % i == 0:
                False
        a.append(x)

    b = len(a)
    c = sum(a)
    # print(a)
    return b,c

number=eval(input())
result=prime(number)
print(result[0],result[1])

# def isPrime(num):
#     if n >= 2 and type (n) == int:
#         for i in range(2,n//2+1):
#             if n % i == 0:
#                 return False
#         return True

# def reverseNumber(num):
#     a = str(n)[::-1]
#     b = int(a)
#     return b

# N = int(input())
# for n in range(1,N+1):
#         if isPrime(n) and reverseNumber(n) == n:
#                 print(n)