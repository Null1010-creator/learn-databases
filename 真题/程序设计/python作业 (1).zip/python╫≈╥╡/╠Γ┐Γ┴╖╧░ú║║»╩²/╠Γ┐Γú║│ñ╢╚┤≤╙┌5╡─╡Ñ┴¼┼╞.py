# 【问题描述】输入一组扑克牌点数（无序），输出其中长度大于5的单连牌（ 输入中有且只有1副符合要求的单连牌）。
# 单连牌即点数差1的连续单牌，例如3 4 5 6 7 8。不计花色，去掉大小王。10代表扑克牌J, 11代表Q, 12代表K，13代表A，14代表2（扑克牌中2点是最大的牌）

# 【输入形式】一行无序点数，点数间空格分隔
# 【输出形式】一行点数，即1副长度大于5的单连牌，点数间空格分隔

# 【样例输入】13 14  3 3 4 4 5 6 7 10 12 12
# 【样例输出】3 4 5 6 7

def play_card(cards):
    cards.sort()  #排序，每一次找连牌从最小的点数开始
    for start in range(len(cards)):  #遍历cards的每一个元素（都有可能成为连牌的第一张）
        now = cards[start]    #把start位置的牌设为连牌的开始
        count = 1    #连牌张数计数
        seq = [now]    #存放连牌的列表
        while True:              #寻找start位置的牌为起始的连牌
            if now+1 in cards:    
                now = now + 1
                count = count + 1
                seq.append(now)     #更新count,now和seq
            else:
                break      #连牌中断，下一个start
        if count >= 5:    #如果连牌张数大于5
            return  seq
                                                    
origin = input().split()
origin = [eval(x) for x in origin]
result = play_card(origin)
for x in result:
    print(x,end="  ")