# 【问题描述】某大学中国学生的学号ID是8位，例如“20200001”，留学生的学号ID是9位 ，首位是大写"L"，例如“L20200002”。
# 现输入一组学号信息，请统计其中的留学生的人数。

# 【输入形式】一行字符（1个或多个学号），学号间以空格分隔
# 【输出形式】一个整数，即留学生人数

# 【样例输入】20200001 20200002 L20190001 20200001
# 【样例输出】1

def count_foreign(ids):
    a = 0
    for i in ids:
        if len(i) == 9:
            a += 1
        # print(len(ids))
    return a

origin = input().split()
# print(origin)
print(count_foreign(origin))