# 【问题描述】统计中的方差（样本方差）是每个样本值与全体样本值的平均数之差的平方值的平均数。
# 在许多实际问题中，研究方差即偏离程度有着重要意义。

# 【输入形式】一行整数（一个或多个），以空格分隔
# 【输出形式】一个小数，即所求方差，保留2位小数
# 【样例输入】1 3 2 4
# 【样例输出】1.25

def  compute_variance(number2):
        ave=sum(number2)/len(number2)
        mySum=0
        for x in number2:
            mySum+=(x-ave)**2
        variance=mySum/len(number2)
        return variance

origin=input().split()
number1=[eval(x)  for  x  in  origin]
print("%.2f"%compute_variance(number1))