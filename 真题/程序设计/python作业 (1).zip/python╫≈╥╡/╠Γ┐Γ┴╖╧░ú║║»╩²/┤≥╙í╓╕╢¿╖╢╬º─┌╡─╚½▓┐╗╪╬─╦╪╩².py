# 问题描述】
# 回文素数是指一个数既是素数又是回文数，例如131既是素数又是回文数。请实现下述两个函数，
# 帮助测试程序完成如下功能：从键盘输入正整数N， 打印从1 ~ N(包含N)的全部回文素数，一行一个。

# 函数接口定义：
# def isPrime(num):
# def reverseNumber(num):

# isPrime()用于判断整数num是否是素数，是返回True, 否则返回False. reverseNumber()用于返回整数num的反向数，
# 321的反向数为123， 320的反向数为23。

# 【样例输入】
# 400
# 【样例输出】
# 2
# 3
# 5
# 7
# 11
# 101
# 131
# 151
# 181
# 191
# 313
# 353
# 373
# 383

def isPrime(num):
    if n >= 2 and type (n) == int:
        for i in range(2,n//2+1):
            if n % i == 0:
                return False
        return True

def reverseNumber(num):
    a = str(n)[::-1]
    b = int(a)
    return b

N = int(input())
for n in range(1,N+1):
        if isPrime(n) and reverseNumber(n) == n:
                print(n) 