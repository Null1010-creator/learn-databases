# 编写函数计算f(i) = 1/2 + 2/3 + 3/4 + ... + i/(i+1) -《Python编程基础及应用》习题8-4
def f(v):
    a = 0
    for i in range(1,v+1):
        a = a + i/(i+1)
    return a

v=int(input())
print("%.4f"  %  f(v))