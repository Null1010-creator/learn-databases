# 【问题描述】输入一个英文字符串，编写递归函数使其逆序输出，输出字符串的开头用#符号表示。

# 【输入形式】一行字符串
# 【输出形式】一行字符串，以#开头，后接输入字符串的逆序输出

# 【样例输入】abc
# 【样例输出】#cba


def myFun(para2):            
    if len(para2) == 0:    #递归结束条件
        print("#",end="")              
    else:
        myFun(para2[1:])                
        print(para2[0],end= "")
        
para1=input()
myFun(para1)  #调用自定义函数