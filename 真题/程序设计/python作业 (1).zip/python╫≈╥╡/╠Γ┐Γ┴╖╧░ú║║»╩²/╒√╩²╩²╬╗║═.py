# 编写一个函数，该函数接受一个正整数作为参数，返回该整数的各位数字之和。

def digitSum(a):
    b = str(a)
    c = len(b)
    d = 0
    for i in range(c):
        d += int(b[i])
    return d

a = int(input())
print(digitSum(a))