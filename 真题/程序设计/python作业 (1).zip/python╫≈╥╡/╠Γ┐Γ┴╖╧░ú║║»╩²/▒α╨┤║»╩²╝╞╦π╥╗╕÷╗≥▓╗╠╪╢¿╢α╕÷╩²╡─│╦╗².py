# 【问题描述】
# 编写函数计算一个或不特定多个数的乘积

# 函数接口定义：
# def caculate(*t)

# 打*号的参数t接受多个参数成员，参数成员预期为整数或浮点数类型。

# 【样例输入】
# 3 2 1
# 【样例输出】
# 6.0000

def caculate(*t):
    m = 1
    for i in t:
        m *= i
    return m

s = input().split()
t = [float(x) for x in s]
print("%.4f"%caculate(*t))

# def caculate(*a):
#     m = 1
#     for i in a:
#         m *= i
#     return m

# print("%.4f"%caculate(*a))