# 【问题描述】编写一个函数，可以接收任意数量的参数（0-3个）。
# 参数的个数及参数值由用户输入，参数值都是正整数。函数的功能是返回所有参数的乘积，如果实际参数个数为0，返回-1。
# 【输入形式】一行正整数，以空格分隔。 第一个整数为参数个数，后面的整数为参数值。
# 【输出形式】一个整数，即所有参数的乘积或者－1

# 【样例输入】0
# 【样例输出】-1

# 【样例输入】1 1
# 【样例输入】1

# 【样例输入】2 2 5
# 【样例输入】10

# 【样例输入】3 2 5 6
# 【样例输入】60



def  test(*para):
    if len(para) == 0:
        return -1
    else:
        s = 1
        for i in para:
            s = s*i
        return s

origin=input().split()
origin=[eval(x)  for  x  in  origin]
number=origin[0]    #获取参数个数
if  number==0:
    result=test()
elif  number==1:
    result=test(origin[1])
elif  number==2:
    result=test(origin[1],origin[2])
elif  number==3:
    result=test(origin[1],origin[2],origin[3])
print(result)