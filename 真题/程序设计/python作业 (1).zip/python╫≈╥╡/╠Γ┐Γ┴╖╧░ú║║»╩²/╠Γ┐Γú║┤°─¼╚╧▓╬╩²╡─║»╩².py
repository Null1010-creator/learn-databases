# 【问题描述】请填空完成以下程序，用户如果输入default, 输出2*2的*号组成的矩阵。用户如果输入一个正整数n，输出n*n的*号组成的矩阵

# 【输入形式】default或一个正整数n, 0<n<10
# 【输出形式】*号组成的矩阵, 一行的*号间用1个空格分隔, 行间无空行

# 【样例输入】default
# 【样例输出】
# **
# **
# 【样例输入】3
# 【样例输出】
# ***
# ***
# ***

def matrix(n=2):
    for i in range(n):
        str1 = '* '*n
        # str2 = str1
        print(str1)

number = input()
if number == "default":
    matrix()  #无实参调用自定义函数
else:
    matrix(n = int(number))
    #有实参调用自定义函数
