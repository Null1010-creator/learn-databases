# 【问题描述】现有4种零钱分别面值25元，10元，5元，1元。输入一定的货币数值，输出找零钞票张数最小的方案。（可使用穷举法）

# 【输入形式】一个正整数n， 例如35，代表35元，0<n<100
# 【输出形式】五个整数，空格分隔，即找零张数最少方案的总张数，25元，10元，5元，1元的张数。

# 【样例输入】35
# 【样例输出】2 1 1 0 0
# 【样例说明】35元最少需要2张钞票，25元1张，10元1张，5元0张，1元0张

def change(n):  #该函数需要返回5个值（可存入列表），即最优方案的总张数及各种钞票的张数，可以使用穷举法
    inumber = []
    a = n // 25
    b = n % 25
    c = b // 10
    d = b % 10
    e = d // 5
    f = d % 5
    g = f // 1
    h = a + c + e + g
    inumber.append(h)
    inumber.append(a)
    inumber.append(c)
    inumber.append(e)
    inumber.append(g)
    return inumber

number=eval(input())
result=change(number)
for  x  in  result:
    print(x,end="  ")