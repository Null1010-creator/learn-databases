# 【问题描述】输入正整数n，输出[2,n)范围内各位数字之和为10的素数，20<n<1000
# 【输入形式】一个正整数n,20<n<1000
# 【输出形式】一行正整数，即[2,n)范围内各位数字之和为10的素数，1个空格分隔

# 【样例输入】100
# 【样例输出】19 37 73

def prime(n):     
    for i in range(3,n):     #for循环
        for j in range(2,i):
            if(i%j==0):
                break
        else:
            if sum_digits(i) == 10:     #调用sum_digits函数计算各位数字之和，判断是否为10
                print(i,end="  ")
                        
def sum_digits(m):  #计算各位数字之和
    s = str(m)
    mysum = 0
    for k in s:
        mysum = mysum + int(k)     #累加求和
    return mysum  

number = eval(input())
prime(number)