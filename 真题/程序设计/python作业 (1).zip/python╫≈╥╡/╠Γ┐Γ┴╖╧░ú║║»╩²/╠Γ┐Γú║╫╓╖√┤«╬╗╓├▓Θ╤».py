# 【问题描述】补充完整函数strrindex(s,t),其功能用于返回字符串t在字符串s中最右边出现的位置.该位置从0开始计数，如果s中不含有t,那么返回-1;
# 在你编写的程序中,使用strrindex(s,t)函数,输入t,s,输出t在s最右边的位置.

# 【输入形式】控制台分行输入字符串s,t.
# 【输出形式】控制台输出一个整数，是t在s最右边出现的位置.

# 【样例输入】The strdup() function new returns a pointer to a new string
# new
# 【样例输出】49

# 【样例说明】输入的第一行为字符串s,第二行为字符串t="new".t在s中出现过两次,其中在最右边出现的位置中"new"的第一个字符&rsquo;n&rsquo;在s中所在的位置为49.

def strrindex(s,t):
    pos = 0
    pos1 = -1
    while True:
        pos = s.find(t,pos)
        if pos == -1:    #如果找不到 返回-1时
            break
        else:
            pos1 = pos
        pos = pos + len(t)
    return pos1

# if__name__=="__main__":
s=input()
t=input()
print(strrindex(s,t))

# 第一次 
# pos = s.find(t,pos) = 22     第22个字母开始是new
# pos1 = pos = 22              pos1 真正表示位置的量  pos 动态变量
# pos = pos + len(t) = 25      下一次s.find(t,pos) 从第25个开始检查new

# 第二次
# pos = s.find(t,pos) = 49     第49个字母开始是new
# pos1 = pos = 49
# pos = pos + len(t) = 52      下一次s.find(t,pos) 从第52个开始检查new

# 第三次
# pos = s.find(t,pos) = 22      后面不再出现new 返回值-1
# 循环结束
# 函数返回真正储存位置的量pos1