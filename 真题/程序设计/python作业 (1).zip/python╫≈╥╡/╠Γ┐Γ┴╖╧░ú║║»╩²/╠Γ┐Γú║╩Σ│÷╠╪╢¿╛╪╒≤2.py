# 【问题描述】用户输入正整数n，1<=n<=9，输出n×n正整数矩阵，副对角线填1，右下三角填2，左上三角填3。
# 例如：n=4, 输出矩阵如下：
# 3331
# 3312
# 3122
# 1222

# 【输入形式】一个正整数，值在[1,9]区间
# 【输出形式】n×n正整数矩阵，副对角线填1，右下三角填2，左上三角填3（行元素间隔1个空格，行间无空行）

# 【样例输入】3
# 【样例输出】
# 331
# 312
# 122


def  print_matrix(n):
    matric = [[0 for c in range(n)] for r in range(n)]
    for r in range(n):
        for c in range(n):
            if r + c < n - 1:
                matric [r][c] = 3
            elif r + c == n - 1:
                matric[r][c] = 1
            else:
                matric[r][c] = 2
    for r in range(n):
        for c in range(n):
            print(matric[r][c],end=" ")
        print()

number=eval(input())
print_matrix(number)