# 【问题描述】中位数是按顺序排列的一组数据中居于中间位置的数。
# 中位数计算方法：如果值有奇数个，可以通过把所有值高低排序后找出正中间的一个作为中位数;
# 如果值有偶数个，通常取最中间的两个数值的平均数作为中位数

# 【输入形式】一行整数（一个或者多个），整数之间使用空格间隔
# 【输出形式】一个小数，即中位数，保留小数2位

# 【样例输入】-1 2  6 4 -2
# 【样例输出】2
# 【样例输入】-1 2  6 4 -2 8
# 【样例输出】3

def  medium(number2):
        number2.sort()
        x=len(number2)//2
        if len(number2) % 2 != 0:
            med=number2[x]
        else:
            med=(number2[x]+number2[x-1])/2
        return med

origin=input().split()
number1=[eval(x)  for  x  in  origin]
print("%.2f"%medium(number1))