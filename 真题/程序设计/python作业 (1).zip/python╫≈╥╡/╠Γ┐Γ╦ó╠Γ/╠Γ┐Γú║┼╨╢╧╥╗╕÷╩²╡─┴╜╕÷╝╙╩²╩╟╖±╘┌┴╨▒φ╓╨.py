# 【问题描述】
# 读入一个列表nums和整数n，判断构成n的两个加数是否在列表中。每个元素可以使用多次。如果存在，这输出True，不存在输出False。

# 【输入形式】
# 第一行输入列表，包括方括号，列表元素逗号分隔
# 第二行输入整数

# 【输出形式】
# True或者False

# 【样例输入】
# [1,2,2,3]
# 6

# 【样例输出】
# True

# 【样例说明】
# 输入的样例中，6=3+3，所以结果输出为True
# 如果第二行输入的是7。则输出False

nums = eval(input())
n = eval(input())
for x in nums:
    if n - x in nums:
        print(True)
        break
else:
    print(False)