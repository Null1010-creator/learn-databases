# 输入一行字符（不能输入中文字符），分别统计出该字符串英文字符、空格、数字和其他字符的个数

letters,space,digit,other=0,0,0,0
s=input()

for i in range(len(s)):
    if (s[i]>='a' and s[i]<='z') or (s[i]>='A' and s[i]<='Z'):
        letters+=1
    elif s[i]==' ':
        space+=1
    elif s[i]>='0' and s[i]<='9':
        digit+=1
    else:
        other+=1

print(letters,space,digit,other)