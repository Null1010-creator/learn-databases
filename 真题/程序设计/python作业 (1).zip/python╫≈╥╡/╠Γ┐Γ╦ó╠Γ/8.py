import io

import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8')

sys.stdin = io.TextIOWrapper(sys.stdin.buffer,encoding='utf-8')

num_dic = {'0':u'零', '1':u'壹', '2':u'贰', '3':u'叁', '4':u'肆', '5':u'伍', '6':u'陆', '7':u'柒', '8':u'捌', '9':u'玖'}
unit_dic = {0:u'仟', 1:'佰', 2:'拾', 3:'万', 4:'仟', 5:'佰', 6:'拾', 7:''}
decimal_dic={0:u'角',1:u'分',2:u'厘',3:u'毫'}
def convert_int(num):
    temp = []
    t = str('%8d'%abs(num))    #重点：把数字换成固定长度8位的字符串
    for s in range(0,4):
        if t[s] != ' ' and t[s] != '0':
            temp.append(num_dic[t[s]])
            temp.append(unit_dic[s])
        if t[s] == '0' and s <3 and t[s+1] != '0':
            temp.append(num_dic[t[s]])
    if(t[2] != ' ' and t[3] == '0'):
        temp.append('万')
    for s in range(4,8):
        if t[s] != ' ' and t[s] != '0':
            temp.append(num_dic[t[s]])
            temp.append(unit_dic[s])
        if t[s] == '0' and s < 7 and t[s+1] != '0':
            temp.append(num_dic[t[s]])
    temp = ''.join(temp)
    if num < 0:
        temp = '负' + temp
    if num == 0:
        temp = '零' + temp

    return temp + u'元'

def convert_decimal(num):
    t = str('%4d'%num)
    temp = []
    for s in range(0,4):
        if t[s] != ' ' and t[s] != '0':
            temp.append(num_dic[t[s]])
            temp.append(decimal_dic[s])
        if t[s] == '0' and s < 3 and t[s + 1] != '0':
            temp.append(num_dic[t[s]])
    temp = ''.join(temp)
    if len(temp) == 0:
        return '整'
    return temp

def convert_money(money):
    num = round(float(money),4)
    integer,decimal = str(num).split('.')
    result_int = convert_int(int(integer))
    result_decimal = convert_decimal(int(decimal))
    return result_int+result_decimal
 
money = input()
print(convert_money(money))

