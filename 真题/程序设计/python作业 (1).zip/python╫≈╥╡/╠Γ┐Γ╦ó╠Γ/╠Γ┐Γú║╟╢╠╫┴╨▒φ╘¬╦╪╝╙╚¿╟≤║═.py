# 输入一个嵌套列表，嵌套层次不超过5次，根据层次，求列表元素的加权和，权是指元素在嵌套列表中的层次。第一层每个元素的权值为：元素值*1，
# 第二层每个元素的权值为：元素值*2，第三层每个元素的权值为：元素值*3，…,以此类推！

# 输入形式：
# 按照列表的形式输入，每个元素是一个整数

# 输出形式：
# 整数

# 样例输入:
# [1,2,[3,4,[5,6],7],8]

# 样例输出:
# 72

ls = eval(input())  #把输入转换成列表，而不是直接用字符的方式处理
def sumlist(ls,level):    #传入一个列表和当前的层数
    sum=0    #加权和，初始化为0
    for i in ls:    #遍历列表中每一个元素
        if type(i) == int:    #如果这个元素的类型是整数形
            sum += i*level      #就计算它的加权和
        else:                    #如果不是整数型，说明它是一个列表
            sum += sumlist(i,level+1)    #那么就进行下一层次的加权和
    return sum    #最后返回加权和

sum=sumlist(ls,1)    #刚开始是在第一层
print(sum)


# def sumlist(ls,level):
#     sum=0
#     for i in ls:
#         if type(i) == int:
#             sum+=i*level
#         else:
#             sum+=sumlist(i,level+1)
#     return sum

# nums  =  eval(input())
# addv  =  sumlist(nums,  1)
# print(addv)