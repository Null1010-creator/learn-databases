def f(x):
    if x < 20:
        s = 6 * (x**2) + 1
    elif 20 <= x < 40:
        s = (3 * x - 60)**0.5
    else:
        s = 100 / (x + 1)
    return s

f = f(eval(input()))
print('%.2f'%f)