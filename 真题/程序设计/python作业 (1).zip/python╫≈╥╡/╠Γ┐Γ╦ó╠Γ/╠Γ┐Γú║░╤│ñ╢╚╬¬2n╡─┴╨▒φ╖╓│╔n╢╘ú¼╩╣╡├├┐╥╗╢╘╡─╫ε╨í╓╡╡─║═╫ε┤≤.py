# 给定长度为2n的自然数列表nums，把这些数分成n对，把每一对的最小值加起来（不同的分法，其和可能不同），输出最小值和的最大值。
# 把列表按照某种分法，分成n对，把每一对的最小值加起来。不同的分法，其和是不同的。
# 例如[1,4,3,2]可以分为：4,1和3,2  或者 4,2和3,1；或者4,3和2,1；
# 显然4,3和2,1这种分法最小值的和最大，3+1=4，前面两种最小值都是3。所以输出结果4.

def maxsum(nums):
    nums.sort()
    a = []
    for i in range(len(nums)):
        if i % 2 == 0:
            a.append(nums[i])
    b = sum(a)
    return(b)

nums  =  eval(input())
v  =  maxsum(nums)#调用自定义函数
print(v)