# 【问题描述】输入学生个人信息,按学号升序排序后写入到文件data.txt中。

# 【输入形式】输入学生个人信息，包括学号，姓名及年龄，用逗号隔开
# 【输出形式】输出每个学生的学号，姓名及年龄

# 【样例输入】
# 1,zs,18
# 2,ls,21
# End
# 【样例输出】
# sno sname sage
#  1   zs    18
#  2   ls    21

# 【样例说明】输入的学生信息用“End”结束



"""
输入学生个人信息,按学号升序排序后写入到文件data.txt中。
"""
f = open('data.txt',  'w+')
f.write("sno\tsname\tsage\n")
ls = []
stext = input() or "End"
while stext != "End":
    ls.append(stext)
    stext = input() or "End"
ls.sort()

for line in ls:
    stu = line.split(",")
    f.write("{}\t{}\t{}\n".format(stu[0],stu[1],stu[2]))
f.seek(0)
print(f.read())
f.close()