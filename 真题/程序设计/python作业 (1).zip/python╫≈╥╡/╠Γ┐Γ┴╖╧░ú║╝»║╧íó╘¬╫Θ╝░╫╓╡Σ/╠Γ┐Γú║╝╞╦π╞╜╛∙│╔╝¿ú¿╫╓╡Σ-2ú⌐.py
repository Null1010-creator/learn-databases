# 问题描述】
# 存储学生Zhang成绩的字典结构如下：
# stu={"name":"Zhang","english":80,"python":90,"math":100}

# 1）请使用上述结构输入学生的name及english、python和math三门课的成绩并存储到字典stu中(不考虑空数据的情况)；
# 2）计算该同学的平均成绩，同时在字典中添加关键字"avg"用来表示平均成绩；
# 3）由高到低排序该学生的各科成绩；
# 4）输出该学生的姓名，各科成绩（保留两位小数）和平均成绩（保留两位小数）。

# 【样例输入】
# Zhang 80 90 100

# 【样例输出】
# Zhang 100.00 90.00 80.00 90.00

# 【样例说明】
# 输入为一行，分别是以空格分隔开的学生姓名、英语成绩、python成绩、数学成绩
# 输出为一行，分别是以空格分隔开的学生姓名、从高到低排序的各科成绩、平均成绩

Name_English_Python_Math = {}
Name_English_Python_Math1 = input()
Name,English,Python,Math = Name_English_Python_Math1.split()

Name_English_Python_Math["name"] = Name
Name_English_Python_Math["english"] = English
Name_English_Python_Math["python"] = Python
Name_English_Python_Math["math"] = Math

a = int(Name_English_Python_Math["english"])
b = int(Name_English_Python_Math["python"])
c = int(Name_English_Python_Math["math"])

sum = a + b + c
avg = sum / 3

d = [a,b,c]
d.sort()
x = d[2]
y = d[1]
z = d[0]

print(Name_English_Python_Math["name"],'%.2f'%x,'%.2f'%y,'%.2f'%z,'%.2f'%avg)
# print(d)