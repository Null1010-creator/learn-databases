# 【问题描述】
# 存储学生Zhang成绩的字典结构如下：
# stu={"name":"Zhang","english":80,"python":90,"math":100}

# 1）请使用上述结构输入3个学生的name及english、python和math三门课的成绩并存储到列表scores中，如下所示：
# scores = [stu1,stu2,stu3]
# 2）计算每个同学的平均成绩，同时在字典中添加关键字"avg"用来表示平均成绩，平均成绩用函数round(avg,2)来保留两位小数；
# 3）按照每个学生的平均成绩由高到低排序输出3个学生的相关信息。

# 【样例输入】
# Zhang 80 90 100
# Li 70 73 80
# Wang 85 83 60

# 【样例输出】
# [{'name': 'Zhang', 'english': 80, 'python': 90, 'math': 100, 'avg': 90.0},
# {'name': 'Wang', 'english': 85, 'python': 83, 'math': 60, 'avg': 76.0},
# {'name': 'Li', 'english': 70, 'python': 73, 'math': 80, 'avg': 74.33}]

# 【样例说明】
# 输入为三行，分别是以空格分隔开的三个学生的姓名、英语成绩、python成绩、数学成绩
# 输出为一行，降序排列的学生成绩列表


Name_English_Python_Math1 = {}
Name_English_Python_Math2 = {}
Name_English_Python_Math3 = {}

Name_English_Python_Math11 = input()
Name1,English1,Python1,Math1 = Name_English_Python_Math11.split()
Name_English_Python_Math1["name"] = Name1
Name_English_Python_Math1["english"] = int(English1)
Name_English_Python_Math1["python"] = int(Python1)
Name_English_Python_Math1["math"] = int(Math1)

Name_English_Python_Math22 = input()
Name2,English2,Python2,Math2 = Name_English_Python_Math22.split()
Name_English_Python_Math2["name"] = Name2
Name_English_Python_Math2["english"] = int(English2)
Name_English_Python_Math2["python"] = int(Python2)
Name_English_Python_Math2["math"] = int(Math2)

Name_English_Python_Math33 = input()
Name3,English3,Python3,Math3 = Name_English_Python_Math33.split()
Name_English_Python_Math3["name"] = Name3
Name_English_Python_Math3["english"] = int(English3)
Name_English_Python_Math3["python"] = int(Python3)
Name_English_Python_Math3["math"] = int(Math3)

a1 = int(Name_English_Python_Math1["english"])
b1 = int(Name_English_Python_Math1["python"])
c1 = int(Name_English_Python_Math1["math"])
sum1 = a1 + b1 + c1
avg1 = sum1 / 3
avg1 = '%.2f'%avg1
Name_English_Python_Math1['avg'] = float(avg1)

a2 = int(Name_English_Python_Math2["english"])
b2 = int(Name_English_Python_Math2["python"])
c2 = int(Name_English_Python_Math2["math"])
sum2 = a2 + b2 + c2
avg2 = sum2 / 3
avg2 = '%.2f'%avg2
Name_English_Python_Math2['avg'] = float(avg2)

a3 = int(Name_English_Python_Math3["english"])
b3 = int(Name_English_Python_Math3["python"])
c3 = int(Name_English_Python_Math3["math"])
sum3 = a3 + b3 + c3
avg3 = sum3 / 3
avg3 = '%.2f'%avg3
Name_English_Python_Math3['avg'] = float(avg3)

lst = []
if avg1 > avg2 and avg1 > avg3 and avg2 > avg3:
    lst.append(Name_English_Python_Math1)
    lst.append(Name_English_Python_Math2)
    lst.append(Name_English_Python_Math3)
    print(lst)
elif avg1 > avg2 and avg1 > avg3 and avg3 > avg2:
    lst.append(Name_English_Python_Math1)
    lst.append(Name_English_Python_Math3)
    lst.append(Name_English_Python_Math2)
    print(lst)

elif avg2 > avg1 and avg2 > avg3 and avg1 > avg3:
    lst.append(Name_English_Python_Math2)
    lst.append(Name_English_Python_Math1)
    lst.append(Name_English_Python_Math3)
    print(lst)
elif avg2 > avg1 and avg2 > avg3 and avg3 > avg1:
    lst.append(Name_English_Python_Math2)
    lst.append(Name_English_Python_Math3)
    lst.append(Name_English_Python_Math1)
    print(lst)
elif avg3 > avg2 and avg3 > avg1 and avg1 > avg2:
    lst.append(Name_English_Python_Math3)
    lst.append(Name_English_Python_Math1)
    lst.append(Name_English_Python_Math2)
    print(lst)
elif avg3 > avg2 and avg3 > avg1 and avg2 > avg1:
    lst.append(Name_English_Python_Math3)
    lst.append(Name_English_Python_Math2)
    lst.append(Name_English_Python_Math1)
    print(lst)

# d = [a,b,c]
# d.sort()
# x = d[2]
# y = d[1]
# z = d[0]

# print(Name_English_Python_Math["name"],'%.2f'%x,'%.2f'%y,'%.2f'%z,'%.2f'%avg)