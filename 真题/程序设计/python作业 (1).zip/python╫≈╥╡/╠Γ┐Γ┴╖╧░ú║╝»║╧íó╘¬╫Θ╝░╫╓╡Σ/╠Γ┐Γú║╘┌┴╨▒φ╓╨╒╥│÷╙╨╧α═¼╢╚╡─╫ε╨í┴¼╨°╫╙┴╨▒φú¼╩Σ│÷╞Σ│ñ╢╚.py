# 【问题描述】
# 给定一个只包含自然数的列表nums。列表的度指的是任一元素出现频率的最大值。找出与nums 拥有相同大小的度的最短连续子列表。输出这个子列表的长度。

# 【输入形式】
# 一个列表，包括方括号，逗号分隔
# 【输出形式】
# 整数

# 【样例输入】
# [1, 2, 2, 3, 1]
# 【样例输出】
# 2

# 【样例说明】
# 输入列表的度是2，因为元素1和2的出现频数最大，均为2。连续子列表里面拥有相同度的有如下所示:
# [1, 2, 2, 3, 1], [1, 2, 2, 3], [2, 2, 3, 1], [1, 2, 2], [2, 2, 3], [2, 2]
# 最短连续子数组[2, 2]的长度为2，输出2.



def displaysublist(A):
    B = []
    for i in range(len(A) + 1):
        for j in range(i + 1, len(A) + 1):
            sub = A[i:j]
            B.append(sub)
    return B

nums = eval(input())
setnums = set(nums)
# listsetnums = list(setnums)
number = []
for i in setnums:
    number.append(nums.count(i))
maxnumber = max(number)                          #求出nums的度

sonnums = displaysublist(nums)                   #求出nums的子列表
# print(sonnums)
sonnumsdu = []
for i in sonnums:
    sonnumber = []
    setsonnums = set(i)
    for x in setsonnums:
        sonnumber.append(i.count(x))
    maxsonnumber = max(sonnumber)                #求出子列表的度
    if maxsonnumber == maxnumber:                #判断子列表度与原列表度是否相同
        sonnumsdu.append(i)
# print(sonnumsdu)                               #与原列表具有相同度的子列表

lens = []
for i in sonnumsdu:
    lens.append(len(i))
minlen = min(lens)
print(minlen)


# numbernums = nums.count(maxnums)
# print(numbernums)