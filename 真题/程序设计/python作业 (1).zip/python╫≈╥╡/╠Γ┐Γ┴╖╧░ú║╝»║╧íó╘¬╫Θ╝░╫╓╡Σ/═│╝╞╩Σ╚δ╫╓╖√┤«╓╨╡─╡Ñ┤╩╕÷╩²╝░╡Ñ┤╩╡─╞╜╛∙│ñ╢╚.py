# 编写一个程序，接受用户输入的一行英文句子
# （假设该句子仅由英文单词及空格构成，不包括逗号等符号），统计并输出该行句子包含的单词个数及单词的平均长度。

String = input()
Lst = String.split(" ")
L = len(Lst)

S = 0
for i in range(len(Lst)):
    S += len(Lst[i])

A = S/L

print("%d,%.2f"%(L,A))
