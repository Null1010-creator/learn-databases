# 【问题描述】
# 输入一个整数列表，调用函数findMax(lst)返回一个字典，其中字典键为最大值位置，值为最大值。如果列表中有多个最大值，则返回第一个位置。

# 【输入形式】
# [整数1，整数2，.....]

# 【输出形式】
# 最大整数位置：最大整数值

# 【样例输入】
# [1,2,3,11,5,6,7,8,9,10]

# 【样例输出】
# 3:11

def findMax(ls):
    a = {}
    b = max(ls)
    c = ls.index(b)
    a[c] = b
    return a

ls = eval(input())
result = findMax(ls)
for i,j in result.items():
    print(str(i) + ":" + str(j))