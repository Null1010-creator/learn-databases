# 问题描述】
# 给定1个整数x,求0~x的阶乘并存入字典。

# 题目要求：
# 完成work函数，实现要求的功能

# 【样例输入】
# 3
# 【样例输出】
# {0: 1, 1: 1, 2: 2, 3: 6}

# 【样例说明】
# 输入：一个整数x
# 输出：0~x的阶乘构成的字典。格式为{0: 1, 1: 1, 2: 2, 3: 6,...,x:x!}


def  work(a) :
    isum = 1
    b = {0:1}
    for i in range(1,a+1):
        isum = i * isum
        b[i] = isum
    return b


a = int(input())
ans = work(a)
print(ans)