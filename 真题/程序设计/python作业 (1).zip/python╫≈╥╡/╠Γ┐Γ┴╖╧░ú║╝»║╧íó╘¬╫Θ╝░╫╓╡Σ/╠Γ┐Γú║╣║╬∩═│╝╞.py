# 【问题描述】
# 某人到超市购买了以下物品，现需要对购物的品种数和购物金额进行统计。清单如下:
# milk 65
# bread 15
# Coke 39
# Biscuit 45
# candy 24
# fruit 35.8
# None

# 至少有一条购物记录，商品不重复，每条记录的格式如上所示，以"None"结束，每条数据是商品名和消费额，空格隔开。

# 题目要求：
# 补全代码，实现题目功能。

# 【样例输入】
# milk 65
# bread 15
# Coke 39
# Biscuit 45
# candy 24
# fruit 5.8
# None

# 【样例输出】
# 6 244.80

# 【样例说明】
# 输入为不定行，以"None"结束，每条数据是水果名和消费额，空格隔开。至少有一条购买记录，商品不重复。
# 输出为一行，分别为商品数量（整数）、购买总金额(浮点数，保留两位小数)，空格隔开



item = input() or "None"
goods = {}
while(item != "None"):
    name,cost = item.split()
    cost = eval(cost)
    goods[name] = cost
    item = input() or "None"
goodsNum = len(goods)
money=0
for i in goods:
    money = goods[i]+money
print(goodsNum,"%.2f"%(money))