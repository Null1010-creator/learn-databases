# 【问题描述】
# 编写一个程序读取未指定个数的字符串(以空格隔开)，找出出现次数最多的字符串及其出现次数。
# 如果出现次数最多的有多个字符串，按照字符串升序输出所有出现次数最多的字符串。
# 例如输入abc bcd abc bcd bbb,那么字符串"abc"和"bcd"出现的次数最多，2次，先输出abc 2，再输出bcd 2。

# 【样例输入】
# abc bcd abc bcd bbb

# 【样例输出】
# abc 2
# bcd 2

# 【样例说明】
# 输入为一行，分别是以空格分隔开的未指定个数的字符串
# 输出为不定行，按照字符串升序排列的出现次数最多的字符串及其出现次数

n = input()
a = list(n.split())
# b = {}
# for i in a:
#     b[i] = a.count(i)
b = []
for i in a:
    b.append(a.count(i))
c = max(b)
d  = []
for x in a:
    if a.count(x) == c:
        d.append(x)
d = set(d)
d = list(d)
d.sort()
for y in d:
    print(y,c)