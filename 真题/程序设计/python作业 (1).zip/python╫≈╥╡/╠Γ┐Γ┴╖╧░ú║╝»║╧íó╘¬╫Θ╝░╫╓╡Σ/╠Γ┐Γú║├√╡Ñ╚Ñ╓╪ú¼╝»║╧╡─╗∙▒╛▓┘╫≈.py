# 【问题描述】
# 录入两份学生名单，采用集合的特点去掉重名，输出同时出现在两个名单里的人，输出两份名单里所有的人（去掉重名）

# 【样例输入】
# William,Jefferson,Clinton,George,Bush,George
# Jack,Jefferson,Lee,George,Wang,Jefferson

# 【样例输出】
# ['George', 'Jefferson']
# ['Bush', 'Clinton', 'George', 'Jack', 'Jefferson', 'Lee', 'Wang', 'William']

# 【样例说明】
# 输入分别是以逗号分隔开的学生名单
# 输出第一行：同时出现在两份名单中的人，升序排列
# 输出第二行：两份名单中的所有人，升序排列



StudentList1 = input().split(',')
StudentList2 = input().split(',')
StudentSet1,StudentSet2 = set(StudentList1),set(StudentList2)
set1 = StudentSet1&StudentSet2  #得到同时出现在两份名单中的人
set2 = StudentSet1|StudentSet2  #得到两份名单中的所有人
print(sorted(list(set1)))
print(sorted(list(set2)))