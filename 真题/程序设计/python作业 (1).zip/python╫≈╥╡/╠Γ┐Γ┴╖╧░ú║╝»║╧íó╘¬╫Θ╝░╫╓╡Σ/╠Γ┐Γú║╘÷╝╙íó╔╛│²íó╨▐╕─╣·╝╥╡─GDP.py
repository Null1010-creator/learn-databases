# 【问题描述】
# 存储国家GDP的字典结构如下：
# GDP = {'USA': 95,'China': 80,'Japan': 50}

# 题目要求：
# 1、请从标准输入录入多个国家的名字和对应的GDP，存入GDP字典中。(字典不为空)
# 2、请修改'China' 这个key对应的value值为95
# 3、删除 'Japan' 这个key
# 4、输出字典的长度和'USA' 这个key对应的value值

# 【样例输入】
# USA 95
# China 80
# Japan 50
# ok

# 【样例输出】
# 2
# 95

# 【样例说明】
# 输入为多行，分别是以空格分隔开的国家和对应的GDP值，以"ok"结束
# 输出第一行：字典GDP的长度
# 输出第二行：'USA' 这个key对应的value值

CountryGDP={}
while True:
    iCountryiGDP = input()
    if iCountryiGDP == "ok":
        break
    iCountry,iGDP = iCountryiGDP.split(" ")
    CountryGDP[iCountry] = iGDP

del CountryGDP['Japan']
CountryGDP['China'] = 95
print(len(CountryGDP))
print(CountryGDP['USA'])