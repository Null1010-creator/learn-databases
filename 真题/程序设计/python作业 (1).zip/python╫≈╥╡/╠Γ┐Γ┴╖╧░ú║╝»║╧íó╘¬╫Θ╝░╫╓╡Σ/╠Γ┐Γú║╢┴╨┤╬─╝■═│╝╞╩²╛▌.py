# 【问题描述】
# 从文件in.txt读取信息，文件里的单词中间由空格隔开
# 统计每个单词出现的次数，从大到小排序后输出到文件out.txt

# 【输入形式】
# 文件里存储了多个单词，有重复，空格隔开

# 【输出形式】
# 从大到小输出单词及其出现的次数，次数一样的单词按字符串比较从小到大排序

# 【输入样例】in.txt文件里面的数据如下所示：
# hello world python hello word file number file file

# 【输出样例】out.txt文件里面的数据如下所示：
# file 3
# hello 2
# number 1
# python 1
# word 1
# world 1


# text1 = open("in.txt","w")
# text1.write("hello world python hello word file number file file")
# text1.close

# text1 = open("in.txt","r")
# line = text1.readline()
# # print(line)

# listline = list(line.split())
# # print(listline)
# setlistline = set(listline)
# numberlistline = {}
# for i in setlistline:
#     numberlistline[i] = listline.count(i)
# # print(numberlistline)

# listnumberlistline = []
# for k,v in numberlistline.items():   #循环中的序列解包
#     listnumberlistline.append([k,v])
# # print(listnumberlistline)

# # 按购买金额降序
# for i in range(len(listnumberlistline)-1 ,0 ,-1):
#     for j in range(0,i):
#         if listnumberlistline[j][1] < listnumberlistline[j+1][1]:
#             listnumberlistline[j],listnumberlistline[j+1] = listnumberlistline[j+1],listnumberlistline[j]
# # print(listnumberlistline)

# # 按购买次数降序
# for i in range(len(listnumberlistline)-1 ,0 ,-1):
#     for j in range(0,i):
#         if listnumberlistline[j][1] == listnumberlistline[j+1][1]:
#             if listnumberlistline[j][0] > listnumberlistline[j+1][0]:
#                 listnumberlistline[j],listnumberlistline[j+1] = listnumberlistline[j+1],listnumberlistline[j]
# # print(listnumberlistline)

# text2 = open("out.txt","w")
# for i in range(len(listnumberlistline)-1):
#     text2.write(str(listnumberlistline[i][0])+' '+str(listnumberlistline[i][1])+'\n')
# text2.write(str(listnumberlistline[len(listnumberlistline)-1][0])+' '+str(listnumberlistline[len(listnumberlistline)-1][1]))
# text2.close

# text2 = open('out.txt','r')
# a = text2.read()
# print(a)
# text2.close

import operator
from os import close
filename = "in.txt"
filenameout = open("out.txt","w")
fp = open(filename,"r")
content = fp.read()
fp.close()
a = content.split()
b = set(a)
c = []
for i in b:
    c.append([i,a.count(i)])

c.sort(key=operator.itemgetter(0))
c.sort(key=operator.itemgetter(1),reverse=True)
for i in c:
    print(i[0],i[1],file = filenameout)
filenameout.close()
print(c)