# 【问题描述】
# 已知数据：有字典employee = {"0001":"Mary","St0002":"Lee","D0003":"Wang"}存储的是雇员号和姓名。
# 从标准输入以如下格式录入销售额字典：
#     第一行录入信息条数
#     第二行开始录入  雇员号-城市 销售数量 用空格隔开
#     存入sales列表
# 数据录入完成后，sales列表的格式如下所示：
#     sales=[["0001-Chongqing",5],["St0002-Shanghai",2], ["St0002-Shanghai",5],["D0003-Nanjing",3], ["St0002-Shanghai",4], ["D0003-Nanjing",1]]
# 根据以上数据，统计每个人的销售业绩并进行降序排序，最后输出排序结果。 

# 【输入形式】
# 从标准输入以如下格式录入销售额字典：
#     第一行录入信息条数
#     第二行开始录入  雇员号-城市 销售数量 用空格隔开
#     存入sales列表，其中雇员号是字典employee中的雇员号，而城市可以随便写
# 数据录入完成后，sales列表的格式如下所示：
#     sales=[["0001-Chongqing",5],["St0002-Shanghai",2], ["St0002-Shanghai",5],["D0003-Nanjing",3], ["St0002-Shanghai",4], ["D0003-Nanjing",1]]
#     其中"0001-Chongqing"表示Mary所属公司是Chongqing，本次销售额为5。

# 【输出形式】
# 按销售额从大到小的顺序输出
# 城市 姓名 销售总额
# 其中城市、姓名是字符串，销售总额是整数，每个元素占10个位置，左对齐。

# 【样例输入】
# 6
# 0001-Chongqing 5
# St0002-Shanghai 2
# St0002-Shanghai 5
# D0003-Nanjing 3
# St0002-Shanghai 4
# D0003-Nanjing 1

# 【样例输出】
# Shanghai  Lee       11
# Chongqing Mary      5
# Nanjing   Wang      4



# 老师讲
employee = {"0001":"Mary","St0002":"Lee","D0003":"Wang"}
n = eval(input())
sales = {}
for i in range(n):
    no_city = input().split()
    no_city[1] = int(no_city[1])
    sales[no_city[0]] = sales.get(no_city[0],0) + no_city[1]

# print(sales)
saleslist = sorted(sales.items(),key = lambda x:x[1],reverse= True)

for e in saleslist:
    pos = e[0].index('-')
    name = employee[e[0][:pos]]
    print("{:<10s}{:<10s}{:<10d}".format(e[0][pos+1:],name,e[1]))



# 自己写
# employee = {"0001":"Mary","St0002":"Lee","D0003":"Wang"}

# a = eval(input())
# b = 0
# sales = []
# while b < a:
#     c = input().split()
#     c = list(c)
#     sales.append(c)
#     b += 1
#     # print(c)
# for i in sales:
#     i[1] = int(i[1])
# # print(sales)

# iMary = []
# iLee = []
# iWang = []
# for i in sales:
#     if i[0][0] == '0':
#         iMary.append(i)
#     elif i[0][0] == 'S':
#         iLee.append(i)
#     elif i[0][0] == 'D':
#         iWang.append(i)
# # print(iMary,iLee,iWang)

# iMarysum = 0
# for i in iMary:
#     iMarysum = iMarysum + i[1]

# iLeesum = 0
# for i in iLee:
#     iLeesum = iLeesum + i[1]
    
# iWangsum = 0
# for i in iWang:
#     iWangsum = iWangsum + i[1]

# iMarycity = 0
# iLeecity = 0
# iWangcity = 0
# if len(iMary) != 0:
#     iMarycity = iMary[0][0][5:]
# if len(iLee) != 0:
#     iLeecity = iLee[0][0][7:]
# if len(iWang) != 0:
#     iWangcity = iWang[0][0][6:]

# iMary1 = [iMarycity,'Mary',iMarysum]
# iLee1 = [iLeecity,'Lee',iLeesum]
# iWang1 = [iWangcity,'Wang',iWangsum]

# if iMarysum > iLeesum and iLeesum >= iWangsum:
#     sales1 = [iMary1,iLee1,iWang1]
# elif iMarysum > iWangsum and iWangsum >= iLeesum:
#     sales1 = [iMary1,iWang1,iLee1]
# elif iLeesum > iMarysum and iMarysum >= iWangsum:
#     sales1 = [iLee1,iMary1,iWang1]
# elif iLeesum > iWangsum and iWangsum >= iMarysum:
#     sales1 = [iLee1,iWang1,iMary1]
# elif iWangsum > iMarysum and iMarysum >= iLeesum:
#     sales1 = [iWang1,iMary1,iLee1]
# elif iWangsum > iLeesum and iLeesum >= iMarysum:
#     sales1 = [iWang1,iLee1,iMary1]
# # print(sales1)

# if sales1[0][0] != 0:
#     for i in range(3):
#         print("{:<10}".format(sales1[0][i]),end="")
#     print()
# if sales1[1][0] != 0:
#     for i in range(3):
#         print("{:<10}".format(sales1[1][i]),end="")
#     print()
# if sales1[2][0] != 0:
#     for i in range(3):
#         print("{:<10}".format(sales1[2][i]),end="")

# # print("{:6}".format(ls[i]),end="")