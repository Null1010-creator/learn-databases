# 【问题描述】
# 录入学生的基本信息，取得学生的姓名、性别和平均成绩（科目数量不确定,但至少有一项）

# 【样例输入】
# '2001001','Zhang San','male',65,False,[76,90,85]

# 【样例输出】
# ('Zhang San', 'male')
# 83.67

# 【样例说明】
# 输入分别是以逗号分隔开的学号，姓名，性别，年龄，是否少数民族，成绩表
# 输出第一行：元组形式表示的学生姓名和性别
# 输出第二行：该生的平均成绩，保留两位小数



student = eval(input())
info = student[1],student[2]
avg = sum(student[-1])/len(student[-1])
print(info)
print("%.2f"%avg)
