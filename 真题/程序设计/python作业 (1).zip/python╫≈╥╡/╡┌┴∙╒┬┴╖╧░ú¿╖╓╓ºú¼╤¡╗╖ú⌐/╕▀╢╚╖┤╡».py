# 一球从 h 米高度自由落下， 每次落地后反跳回原高度的 0.5倍； 再落下， 求它在第 N 次落地时， 共经过多少米？  
h = eval(input())
N = eval(input())
s = h
if N == 1:
    print('%.2f'%s)
else:
    for i in range(1,N):
        s = s + h
        h = h/2
    print('%.2f'%s)