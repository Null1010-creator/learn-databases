# 红色(red)、蓝色(blue)和黄色(yellow)被称为原色(primary color)。 当两种原色混合时，将得到次生色(secondary color)。
# 规则如下： 
# 1.当红色与蓝色混合时，将得到紫色(purple)。 
# 2.当红色与黄色混合时，将得到橙色(orange)。 
# 3.当蓝色与黄色混合时，将得到绿色(green)。 
# 编写一个程序，根据用户输入的欲混合的两种原色，输出混合得到的次生色的名称。 
# 如果用户输入的不是三原色的名称，或者输入的两个颜色相同，则输出“error”

a = input()
b = input()
if a == b:
    print('error')
elif a != 'red' and a != 'blue' and a != 'yellow':
    print('error')
elif b != 'red' and b != 'blue' and b != 'yellow':
    print('error')
else:
    if (a == 'red' and b == 'blue') or (a == 'blue' and b == 'red'):
        print('purple')
    elif (a == 'red' and b == 'yellow') or (a == 'yeliow' and b == 'red'):
        print('orange')
    elif (a == 'yeliow' and b == 'blue') or (a == 'blue' and b == 'yellow') :
        print('green')