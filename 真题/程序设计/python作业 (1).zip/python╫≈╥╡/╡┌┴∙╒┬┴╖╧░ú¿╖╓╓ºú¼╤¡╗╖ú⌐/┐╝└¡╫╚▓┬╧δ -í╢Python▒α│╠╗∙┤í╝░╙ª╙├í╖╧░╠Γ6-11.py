# 考拉兹猜想（Collatz conjecture）又称奇偶归一猜想，是指对于每一个正整数，
# 如果它是奇数，则对它乘3再加1,如果它是偶数，则对它除以2。 如此循环，最终都能得到1。
# 编写一个程序，输入一个正整数，打印其考拉兹序列。.

nums = int(input())
CollatzList=[]
while True:
    if nums !=1:
        if nums%2==0:
            nums = int(nums/2)
        else:
            nums = int(nums*3+1)
        CollatzList.append(nums)

    else:
        break

print(",".join(str(i) for i in CollatzList))
# for x in CollatzList:
#     print(x,end=',')
