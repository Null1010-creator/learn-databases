# 从键盘不断地输入整数，当输入“#”时程序退出，然后打印出所输入整数的个数和总和。

b = []
while True:
    a = input()
    if a == "#":
        break
    b.append(int(a))

c=len(b)

# for i in b:
#     print(i,type(i))

d=sum(b)

print(c,d)
# print(c)