# 输入一个整数，判断它是否能被5、7、11同时整除，若不能，则判断它是否能被5、7、11分别整除。
a = eval(input())
if a%5 == 0 and a%7 == 0 and a%11 == 0:
    print(a,"can divided by 5,7 and 11.")
elif a%5 == 0 and a%7 == 0 and a%11 != 0:
    print(a,"can divided by 5.")
    print(a,"can divided by 7.")
elif a%5 == 0 and a%7 != 0 and a%11 == 0:
     print(a,"can divided by 5.")
     print(a,"can divided by 11.")
elif a%5 != 0 and a%7 == 0 and a%11 == 0:
     print(a,"can divided by 7.")
     print(a,"can divided by 11.")
elif a%5 == 0 and a%7 != 0 and a%11 != 0:
     print(a,"can divided by 5.")
elif a%5 != 0 and a%7 == 0 and a%11 != 0:
     print(a,"can divided by 7.")
elif a%5 != 0 and a%7 != 0 and a%11 == 0:
     print(a,"can divided by 11.")
elif a%5 != 0 and a%7 != 0 and a%11 != 0:
     print(a,"can not divided by 5,7 or 11.")