def  main():
        total_count=int(input())
        calculate_days(total_count)

def calculate_days(total_count):
    days=1
    while total_count>0:
        c=total_count/2+2
        total_count=total_count-round(c,0)
        if total_count>0:
            days+=1
    print(days)

main()