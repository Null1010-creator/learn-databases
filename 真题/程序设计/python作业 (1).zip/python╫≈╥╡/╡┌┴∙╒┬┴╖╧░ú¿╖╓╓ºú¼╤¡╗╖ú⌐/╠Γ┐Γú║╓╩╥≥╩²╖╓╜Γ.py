num = int(input())
b = num
i = 2
a = []
while  num != 1:
    if num % i == 0:
        a.append(i)
        num //= i       #相当于num = num // i
    else:
        i += 1
c = "*".join(str(i) for i in a)
print(str(b)+'='+c)