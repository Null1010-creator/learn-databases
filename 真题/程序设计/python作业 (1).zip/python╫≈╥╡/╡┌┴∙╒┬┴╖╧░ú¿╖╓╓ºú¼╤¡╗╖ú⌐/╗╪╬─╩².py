# 输入一个数， 判断这个数是不是回文数
# （数字 121 从左往右读与从右往左读是一样的， 这种数称为回文数。）（注： 0,1,2,...,9 也是回文数）

n=input()
r=1
for i in range(len(n)):
    if(n[i]!=n[-(i+1)]):
        r=0
        i = i +1
if r==0:
    print("False")
else:
    print("True")