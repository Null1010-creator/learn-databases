n = eval(input())
s = []
for i in range(100,n+1):
    if int(str(i)[0])**3 + int(str(i)[1])**3 + int(str(i)[2])**3 == i:
        s.append(i)
if len(s) == 0:
    print('none')
else:
    for x in range(len(s)):
        print(s[x])