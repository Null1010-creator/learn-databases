# 从键盘输入一段数字， 加密规则如下：对于每一个位置上的数字进行如下处理： 每位数字加上 5，
# 然后除以 10 得到的余数代替该数字，再将第一位和最后一位交换，第二位与倒数第二位交换，依此类推，最后输出加密后的数字密码 。

a = input()
b = len(a)
c = []
i = 0
while i <= b-1:
    d = str((int(a[i]) + 5) % 10)
    c.append(d)
    i += 1
if len(c) % 2 == 0:
    if len(c) == 2:
        c[0],c[-1] = c[-1],c[0]
    else:
        for x in range(int((len(c)/2))):
            c[x],c[len(c)-1-x] = c[len(c)-1-x],c[x]
    e = c[0]
    for y in range(1,len(c)):
        e = e + c[y]
    print(e)
else:
    for z in range(int((len(c)+1)/2)):
        c[z],c[len(c)-1-z] = c[len(c)-1-z],c[z]
    f = c[0]
    for o in range(1,len(c)):
        f = f + c[o]
    print(f)