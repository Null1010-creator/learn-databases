# 【问题描述】输入一个整数，求该整数上的各位数是否包含数字5，若有,则按从低到高的顺序输出第几位,若没有则输出-1

a = str(input())
b = []
for i in range(len(a)):
    if int(a[i]) == 5:
        b.append(i+1)
if len(b) != 0:
    for x in b:
        print(x)
else:
    print(-1)