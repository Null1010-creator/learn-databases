# 折半查找。 1 个列表里存储了 20 个子列表， 各子列表内存储了学生的学号及姓名两个元素， 两个元素都是字符串类型。 
# 现已知该 20 个学生子列表已按学号递增序排好序。
# 请设计一个程序， 使用折半查找算法通过最少次数的比较找到指定学号的学生， 
# 如果有， 输出这个学生的学号和姓名， 如果没有， 输出报告未找到该学生。 
# 列表中存储数据为
# stu_list=
# [['201801','zhangyi'],['201802','zhanger'],['201803','zhangsan'],['201804','zhangsi'],
# ['201805','wangyi'],['201806','wanger'],['201807','wangsan'],['201808','wangsi'],
# ['201809','liyi'],['201810','lier'],['201811','lisan'],['201812','lisi'],
# ['201813','zhaoyi'],['201814','zhaoer'],['201815','zhaosan'],['201816','zhaosi'],
# ['201817','zhouyi'],['201818','zhouer'],['201819','zhousan'],['201820','zhousi']]


stu_list=[['201801','zhangyi'],['201802','zhanger'],['201803','zhangsan'],['201804','zhangsi'],
          ['201805','wangyi'],['201806','wanger'],['201807','wangsan'],['201808','wangsi'],
          ['201809','liyi'],['201810','lier'],['201811','lisan'],['201812','lisi'],
          ['201813','zhaoyi'],['201814','zhaoer'],['201815','zhaosan'],['201816','zhaosi'],
          ['201817','zhouyi'],['201818','zhouer'],['201819','zhousan'],['201820','zhousi']]

# for i in range (len(stu_list)):
#     d = dict.fromkey({stu_list[i][0],stu_list[i][0]})

# print (d)
stuid = input()
for i in range (len(stu_list)):
    if stuid == stu_list[i][0]:
        print(stu_list[i][0]+stu_list[i][1])
        break
    else:
        if i!= len(stu_list)-1:
            continue
        else:
            print("None")


        