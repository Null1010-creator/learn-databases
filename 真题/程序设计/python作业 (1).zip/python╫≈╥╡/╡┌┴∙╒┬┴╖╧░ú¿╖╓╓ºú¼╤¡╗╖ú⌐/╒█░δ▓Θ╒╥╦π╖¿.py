# 折半查找算法：先把被查找值与序列中间位置的元素比较，如果相等表示已找到。
# 如果查找值 < 中位元素，这说明查找值在中位元素的左边，如果查找值 > 中位元素，则说明查找值在中位元素的右边。
# 每进行一次比较，我们大概可以把查找范围缩小一半。
# 这种同中位元素进行比较的方法可以一直持续下去，直到找到或者发现找不到为止。最坏情况下，我们要进行logN次比较，N为序列的长度。
# 下述程序中的binarySearch()函数通过折半查找从列表a中查找并打印输入值v在a中的下标。请将其补充完整。

def  binarySearch(s,v):
    begin,end  =  0,  len(s)-1
    while begin<=end:
        mid  =  (begin+end)//2
        if  s[mid]  ==  v:
            print("Found:%d"  %  mid)
            break
        elif  v  >  s[mid]:
            begin = mid + 1
        else:
            end = mid - 1
    else:
        print("Not  found")

a = [1,3,12,45,66,89,123,154,768,9921]
v = int(input())
binarySearch(a,v)