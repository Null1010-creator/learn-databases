# 从键盘输入两个整数n和m（要求n<m），编程求出由n到m(不包含m)中的整数组合而成的所有不含重复数字的三位数。
# 若n和m的输入不合法或者没有符合条件的三位数则提示输出“illegal input"。

from itertools import permutations
import random 
n,m = map (int,input().split())

if n < m and n+2 < m and n >= 0 and m < 10:
    i = n
    num = []
    while i < m:
        num.append(i)
        i += 1

    A=permutations(num,3)
    B=set(A)
    C=list(B)
    D=[]
    for j in C:
        E=100*j[0]+10*j[1]+j[2]
        D.append(E)
    D.sort()
    for k in D:
        if len(str(k))==3:
            print (k,end=" ")

else:
    print("illegal input"
