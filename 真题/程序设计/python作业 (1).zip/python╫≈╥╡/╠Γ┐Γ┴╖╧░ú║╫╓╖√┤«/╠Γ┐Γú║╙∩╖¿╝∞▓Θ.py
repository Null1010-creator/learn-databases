# 【问题描述】
# 假设一个输入字符串中包含圆括号、方括号和花括号三种类型的括号，以及其它一些任意字符。编写程序，判别字符串串中的括号是否正确匹配，即：
# 1. 各种左、右括号的个数要一致；
# 2. 要符合正确的嵌套规则。

# 【输入形式】
# 输入一个含各种括号的字符串

# 【输出形式】
# 能正确匹配输出True，反之输出False

# 【样例输入】
# [/]{((x)({{*}*}w)w){f}{v}[%(^[z]{u}{ })([[ ]-]h)]{c}(*)[y]}

# 【样例输出】
# True


def func(S):
    mylist=[]
    index = -1
    #由于continue,index不能放在循环体最后，进而index<=len(S)-2
    while index < len(S)-1:
        index += 1
        sym = S[index] #存储字符
        
        if sym == '(' or sym == '[' or sym == '{':
            mylist.append(sym) #有左括号时压栈

        #注意：分类讨论
        else:
            if sym == ')':
                if len(mylist)>0 and mylist.pop()=='(':
                    continue
                else:
                    return False
            if sym == ']':
                if len(mylist)>0 and mylist.pop()=='[':
                    continue
                else:
                    return False
            if sym == '}':
                if len(mylist)>0 and mylist.pop()=='{':
                    continue
                else:
                    return False 
    if len(mylist) == 0:
        return True
    else:
        return False

S = input()
print(func(S))