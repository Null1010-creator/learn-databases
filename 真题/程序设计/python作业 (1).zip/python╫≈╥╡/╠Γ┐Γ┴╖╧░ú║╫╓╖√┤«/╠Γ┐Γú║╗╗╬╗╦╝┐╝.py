# 【问题描述】
# 对字符串由数字和 “*”星型字符两种字符无序构成的stra，，现在想把所有的星型字符挪到数组的左边，数字字符全部放到右边，数字字符之间的相互顺序不变。
# 补充程序中所缺代码，完成上述功能。

# 【输入形式】
# 输入一个有数字和星号构成的字符串
# 【输出形式】
# 换位后的字符串

# 【样例输入】
# 12*23**567
# 【样例输出】
# ***1223567



def main():
    stra = input()
    lista = list(stra)
    print(''.join(replace_stars(lista)))

def replace_stars(str_list):    # 将所有*号移动到数组的左侧
        j = len(str_list)  -  1
        for i in range(len(str_list)-1,-1,-1):
            if str_list[i] != '*':
                str_list[j],str_list[i] = str_list[i],str_list[j]
                j  -=  1
        return  str_list

main()