# 【问题描述】   
# 编写程序，对输入的密码（长度不超过28）进行强度检测。密码强度规定为：
# 1）含有数字字符；
# 2) 含有小写字母； 
# 3）含有大写字母；
# 4）密码长度不低于8；
# 5）至少含有~!@#$%^&*()_=-/,.?<>;:[]{}|\中的一个字符
# 规定密码满足上列任意条件即加一星，程序输出密码的星级

# 【输入形式】
# 长度在28以内的任意字符串。
# 【输出形式】
# 根据密码强度要求，输出密码强度星级，用整数表示

# 【样例输入】
# 123.aq.Aw!
# 【样例输出】
# 5

mima = input()
mimaben = []
for i in mima:
    mimaben.append(i)
# print(mimaben)

xinji = 0

for i in mimaben:
    if '0' <= i <= '9':
        xinji = xinji + 1
        break

for i in mimaben:
    if 'a' <= i <= 'z':
        xinji = xinji + 1
        break

for i in mimaben:
    if 'A' <= i <= 'Z':
        xinji = xinji + 1
        break

if len(mimaben) >= 8:
    xinji = xinji + 1

zifu = ['~','!','@','#','$','%','^','&','*','(',')','_','=','-','/',',','.','?','<','>',';',':','[',']','{','}','|','\\']
for i in mimaben:
    if i in zifu:
        xinji = xinji + 1
        break

print(xinji)