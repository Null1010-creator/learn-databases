# 【问题描述】
# 完成函数def isPalindrome(s)编写，函数功能是判断输入的字符串是否是回文字符串，回文字符串就是正反均为同一字符串。

# 【输入形式】
# 字符串，包含字母和非字母字符。
# 【输出形式】
# 如为回文字符串，输出True，否则输出False。

# 【样例输入】
# abcdcba
# 【样例输出】
# True

# 【样例输入】
# abcd123dcba
# 【样例输出】
# False


def main():
    # Prompt  the  user  to  enter  a  string
    s = input().strip()
    print(isPalindrome(s))

# Check if a string is a palindrome  
def isPalindrome(s):
    slist = list(s)
    slist1 = list(s)
    slist.reverse()
    if slist == slist1:
        return True
    else:
        return False

main()  #  Call  the  main