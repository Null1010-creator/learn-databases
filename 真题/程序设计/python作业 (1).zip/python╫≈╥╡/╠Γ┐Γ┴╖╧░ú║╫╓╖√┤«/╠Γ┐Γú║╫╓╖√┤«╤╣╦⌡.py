
def comparessString(s):
    if len(s) == 0:
        return s
    count = 1
    tmp = s[0]
    res = ""
    for i in range(1, len(s)):
        if s[i] == tmp:
            count += 1
        elif s[i] != tmp:
            if count == 1:
                res = res + str(tmp)
                count = 1
                tmp = s[i]
            else:
                res = res + str(tmp) + str(count)
                count = 1
                tmp = s[i]
    res = res + str(tmp) + str(count)
    if res[-1] == '1':
        res = res[0:-1]
    return res
    # if len(res) < len(s):
    #     return res
    # else:
    #     return s

s = input()
print(comparessString(s))