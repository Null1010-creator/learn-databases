# 【问题描述】
# 最长公共子串,题目描述：a b两个字符串，求a b的最长公共子串，输出最长公共子串长度和最长公共子串，当有多个等长的最长公共子串，输出在a中出现的第一个子串。
# 子串与子序列不同，子串必须是连续的，而子序列可以不连续。

# 【输入形式】
# 分两行输入两个字符串
# 【输出形式】
# 一行输出长度

# 【样例输入】
# abcccabccsccs
# abcabcabccs
# 【样例输出】
# 6


a = input()
b = input()
la = len(a)
lb = len(b)
#建立二维列表，行数la+1，列数lb+1,初值为0
res = [[0 for x in range(lb+1)] for y in range(la+1)]
lc = []
mmax = 0
for i in range(1,la+1):
    for j in range(1,lb+1):
        if a[i-1] == b[j-1]:
            res[i][j] = res[i-1][j-1] + 1
            if(res[i][j] > mmax):
                mmax = res[i][j]            
print(mmax)
# 用一个矩阵来记录两个字符串中所有位置的两个字符之间的匹配情况，若是匹配则为1,否则为0。然后求出对角线最长的1的序列，其对应的位置就是最长匹配子串的位置。