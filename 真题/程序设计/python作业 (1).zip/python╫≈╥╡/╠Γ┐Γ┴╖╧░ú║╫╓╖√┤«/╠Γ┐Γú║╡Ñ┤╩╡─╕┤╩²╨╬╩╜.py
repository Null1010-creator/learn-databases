# 【问题描述】
# 单词的复数形式变化的规则假定如下： 
# 1.以s,x,ch,sh结尾，加es; 
# 2.以o结尾，加es; 
# 3.以y结尾，则将y改成i,再加es; 
# 4.其他情况直接加s。
# 编写一个函数plural(word)将单词word变成复数形式。

# 【输入形式】
# 输入一个单词
# 【输出形式】
# 输出单词的复数形式

# 【样例输入】
# box
# 【样例输出】
# boxes


def main():
    inword = input()
    print(plural(inword))

def plural(inword):
    if inword[-2:] == 'ch' or inword[-2:] == 'sh':
        return inword + 'es'
    elif inword[-1] == 's' or inword[-1] == 'x':
        return inword + 'es'
    elif inword[-1] == 'o':
        return inword + 'es'
    elif inword[-1] == 'y':
        return inword[:-1] + 'ies'
    else:
        return inword + 's'

main()