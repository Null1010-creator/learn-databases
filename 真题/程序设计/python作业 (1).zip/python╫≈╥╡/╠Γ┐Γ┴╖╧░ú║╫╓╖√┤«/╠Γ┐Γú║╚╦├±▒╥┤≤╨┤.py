# 【问题描述】
# 在发票上通常要加印大写汉字金额，编写一个程序，对键盘上输入一个20位内的整数，将其转换为大写汉字的人民币金额。

# 【输入形式】
# 输入一个整数

# 【输出形式】
# 输出大写的人民币金额

# 【样例输入】
# 123456789

# 【样例输出】
# 壹亿贰仟叁佰肆拾伍万陆仟柒佰捌拾玖元整

# 【样例说明】
# 为解决系统中文不能输出问题，请在源程序前面加上下面语句：

import io
import sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8')
sys.stdin = io.TextIOWrapper(sys.stdin.buffer,encoding='utf-8')

num = ['零','壹','贰','叁','肆','伍','陆','柒','捌','玖']
follow2 = ['仟','佰','拾','']
follow3 = ['亿','万','']

def change(a):
    result = ""
    for i in range(len(a)):
        if a[i] != '0':
            result += num[int(a[i])] + follow2[4-len(a)+i]
        elif i > 0 and a[i] == "0" and a[i-1] != "0":
            result += "零"
        elif i > 0 and a[i] == "0" and a[i-1] == "0":
            result += ""
        elif i == 0 and a[i] == "0":
            result += '零'
    if result[-1] == '零':
        result = result[:-1]
    return result

money = input()
lmoney = []
if len(money) > 8:
    lmoney = [money[:-8],money[-8:-4],money[-4:]]
elif len(money) > 4:
    lmoney = ["",money[:-4],money[-4:]]
else:
    lmoney = ["","",money[:]]

afterchange = ""
for i in range(len(lmoney)):
    if change(lmoney[i]) != "":
        afterchange += change(lmoney[i]) + follow3[i]

if afterchange == "":
    afterchange = '零'
afterchange += "元整"
print(afterchange)