# 【问题描述】
# 请删除一个非空字符串中多次出现的字符，仅保留最先出现的一个，例 ‘abcabb’，经过去除后，输出 ‘abc’。
# 编写函数strreduce(str)实现其功能，函数返回“瘦身”后的字符串。

# 【输入形式】
# 一个非空字符串
# 【输出形式】
# 瘦身后的字符串

# 【样例输入】
# adefbafdsaf
# 【样例输出】
# adefbs


def main():
    a  =  input()
    print(strreduce(a))

def strreduce(a):
    # alist = list(a)
    # aset = set(alist)
    # print(aset)
    b = []
    c = ""
    for i in a:
        if i not in b:
            b.append(i)
            c = c + i
    return c

main()