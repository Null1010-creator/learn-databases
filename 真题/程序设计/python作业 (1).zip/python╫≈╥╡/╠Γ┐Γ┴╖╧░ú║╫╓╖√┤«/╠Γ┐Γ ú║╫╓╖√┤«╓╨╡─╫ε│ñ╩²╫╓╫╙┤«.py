# 【问题描述】
# 本题目要求读入一个字符串，输出字符串的最长数字子串。

# 【输入形式】
# 输入一个字符串
# 【输出形式】
# 输出最长数字子串，若有多个最长数字子串输出最后一个，若字符串无数字字符，则输出“No digits”。

# 【输入样例】
# sdffsd123werrer456fgdgdg1dfgdf12
# 【样例输出】
# 456 



# def Int(w):
#     wlist = list(w)
#     b = 0
#     for x in wlist:
#         if type(eval(x)) == int:
#             b += 1
#     if b > 0:
#         return 1
#     else:
#         return 0

# n = input()
# if Int(n) == 1:
#     count = 0
#     length = 0
#     temp = []
#     dig = []

#     for i in range(len(n)):
#         if n[i] >= '0' and n[i] <= '9':
#             count += 1
#             temp.append(n[i])
#         else:
#             if count >= length:          # 数字串大于之前的，由于题目要求长度相等输出最后一串，所以这里要用大于等于
#                 length = count
#                 count = 0
#                 dig = temp.copy()
#                 temp = []
#             else:      # 数字串较短则清空
#                 temp = []
#                 count = 0
#     print(''.join(dig))
# else:
#     print("No digits")


a=input()
lst1=list(a)
b=''
c=''
for i in lst1:
    if i.isdigit():
        b=b+i
    else:
        b=b+' '
# print(b)
b=b.split(" ")
lst2=list(b)
lst3=[]
lst4=[]
# print(lst2)
for m in lst2:
    if m.isdigit():
        m=eval(m)
        lst3.append(m)
count=0
sum=0
for n in lst3:
    lst4=[int(x) for x in str(n)]
    # print(lst4)
    if len(lst4)>count:
        count=len(lst4)
        sum=n
    elif len(lst4)==count:
        sum=n
if sum!=0:
    print(sum)
else:
    print('No digits')