# 【问题描述】
# 字符串反码的定义为：字符串所包含字符的反码组成的字符串。
# 字符反码的定义为：
# (1) 对于小写英文字符，它的反码也是一个小写英文字符，且该字符与'a'的距离等于其反码与'z'的距离；
# (2) 对于大写英文字符，它的反码也是一个大写英文字符，且该字符与'A'的距离等于其反码与'Z'的距离；
# 两个字符距离指其对应unicode编码之差。

# 【样例输入1】
# ABCabc
# 【样例输出1】
# ZYXzyx

# 【样例输入2】
# Hello World
# 【样例输出2】
# Svool Dliow

# 【样例说明】
# 对于非英文字母的字符，保持不变


mima = input()
mima1 = list(mima)

mimaben1 = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
mimaben2 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

yuanwen = ''
for i in mima1:
    if i >= 'A' and i <= 'Z':
        a = mimaben1.index(i)
        yuanwen = yuanwen + mimaben1[25-a]
    elif i >= 'a' and i <= 'z':
        a = mimaben2.index(i)
        yuanwen = yuanwen + mimaben2[25-a]
    else:
        yuanwen = yuanwen + i

print(yuanwen)