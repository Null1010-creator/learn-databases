# 问题描述】
# 字符串的旋转是指：把字符串前面的若干字符移动到字符串的尾部，比如：把字符串"abcdef"前2位字符移动到后面得到字符串为“cdefab“，
# 可以把字符串看成两段，分别即为XY，左旋转相当于把字符串XY变成YX。编写一个函数，判断字符串s1是否由字符串s2旋转而来，函数头：is_rotation(s1,s2)

# 【输入形式】
# 分行输入两个字符串
# 【输出形式】
# 成立输出True，不成立输出False

# 【样例输入】
# stringbook
# bookstring
# 【样例输出】
# True


def main():
    s1 = input()
    s2 = input()
    print(is_rotation(s1,s2))

def is_rotation(s1,s2):
    i = 1
    while i <= len(s2):
        s3 = s2[0:i]
        s4 = s2[i:]
        s5 = s4 + s3
        if s5 == s1:
            return True
        else:
            i = i + 1
    return False

main()
