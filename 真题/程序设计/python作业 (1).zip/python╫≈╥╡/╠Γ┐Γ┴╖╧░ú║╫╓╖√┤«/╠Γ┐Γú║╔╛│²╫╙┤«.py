# 【问题描述】
# 编写一个程序，当在一个字符串中出现指定子串时就删除它。

# 【输入形式】
# 用户在第一行输入一个字符串，用户在第二行输入一个子串。
# 【输出形式】
# 程序在下一行输出删除其中所有子串后的字符串。如果字符串不包含子串则输出原字符串本身。

# 【样例输入】
#  I am a boy!
#  a            
# 【样例输出】
#  I m  boy!

# 【样例说明】用户首先输入字符串I am a boy!,然后输出子串a,程序会寻找字符串中的子串删除它，最后   将删除后的结果输出:I#m##boy!   #表示空格。


# 1.0版本(仅能删除一个字符)
# a = input()
# b = input()
# alist = list(a)
# alist1 = []
# for i in alist:
#     if i != b:
#         alist1.append(i)
# a1 = ''
# for i in alist1:
#     a1 = a1 + i
# print(a1)

# 2.0版本
# a = input()
# b = input()
# c = len(a)
# d = len(b)
# alist = []
# for i in range(0,c-d+1):
#     alist.append(a[i:i+d])
# # print(alist)
# alist1 = []
# for i in alist:
#     if i == b:
#         alist1.append(alist.index(i))
# # print(alist1)
# e = ""
# for i in alist1:
#     e = e + a[:i]

a = input()
b = input()
c = a.replace(b,'')
print(c)