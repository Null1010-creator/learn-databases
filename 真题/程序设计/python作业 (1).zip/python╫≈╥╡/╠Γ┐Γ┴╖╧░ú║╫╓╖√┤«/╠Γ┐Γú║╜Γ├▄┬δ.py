# 【问题描述】
# 有一行电文，已按下面规律译成密码：
#      A--Z   a--z
#      B--Y   b--y

#      C--X   c--x

#      ......

# 即第1个字母变成第26个字母，第i个字母变成第（26-i+1）个字母; 非字母字符不变。编写程序把密码译回原文，并输出密码和原文。

# 【输入形式】
# 输入一串密码
# 【输出形式】
# 首先输出密码，然后换行后输出原文

# 【样例输入】
# 4sdf&13TBD

# 【样例输出】
# 4sdf&13TBD
# 4hwu&13GYW

mima = input()
mima1 = list(mima)

mimaben1 = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
mimaben2 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

yuanwen = ''
for i in mima1:
    if i >= 'A' and i <= 'Z':
        a = mimaben1.index(i)
        yuanwen = yuanwen + mimaben1[25-a]
    elif i >= 'a' and i <= 'z':
        a = mimaben2.index(i)
        yuanwen = yuanwen + mimaben2[25-a]
    else:
        yuanwen = yuanwen + i

print(mima)
print(yuanwen)