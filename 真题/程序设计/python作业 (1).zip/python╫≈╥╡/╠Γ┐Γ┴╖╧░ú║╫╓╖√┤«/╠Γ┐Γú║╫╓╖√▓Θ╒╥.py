# 【问题描述】
# 在输入字符串中查找指定字符，如查找到返回其第一次出现的下标，如不存在返回None。

# 【输入形式】
# 输入一个字符串
# 查找字符
# 【输出形式】
# 元素下标或None

# 【样例输入】
# abcdefgh
# f
# 【样例输出】
# 5


def main():
    s = input()
    ch = input()
    print(count(s,ch))

def count(s,ch):
    for i in range(len(s)):
        if ch == s[i]:
            return i
    return  None

main()