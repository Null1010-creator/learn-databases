def shift(lst):
    alpha = lst.pop(len(lst)-1)
    lst.insert(0,alpha)
    return lst

list1 = input().split(",")
shift(list1)
print(list1)