# 请编写一个程序，根据用户输入的一个人的年龄，程序将判断说明这个人是婴儿、儿童、青年人或者成年人。
# 分类的原则如下：
# 1.如果此人是1岁甚至更小，则为婴儿(infant)
# 2.如果此人大于1岁，但小于13岁，则为儿童(child)
# 3.如果此人至少13岁，但小于20岁，则为青年人(teenager)
# 4.如果此人至少20岁，则为成年人(adult)
# 如果输入的数小于等于0，则输出“Error”
age=eval(input())

if  0<age<=1:
    print("infant")
elif  1<age<13:
    print("child")
elif  13<=age<20:
    print("teenager")
elif  age>=20:
    print("adult")
else:
    print("Error")