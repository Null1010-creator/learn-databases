# 请用户输入3个整数，若其中有两个值相等，则提示中奖，否则提示谢谢参与
number_a,number_b,number_c  =eval(input())
number_a=int(number_a)
number_b=int(number_b)
number_c=int(number_c)
if number_a ==number_b or number_a ==number_c or number_b==number_c:
    print("WIN!")
else:
    print("Thank  You!")