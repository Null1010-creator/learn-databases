def digitSum(a):
    a = str(a)
    b = []
    for i in range(len(a)):
        b.append(int(a[i]))
    c = sum(b)
    return(c)

a  =  int(input())
print(digitSum(a))