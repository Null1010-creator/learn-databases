# 定义一个元组，数据为输入的列表，列表存放n个整数。计算它的中位数。
a = eval(input())
# b = tuple(a)
# c = len(b)
# if c % 2 != 0:



# c = b[1]
# print(b)

b = len(a)
if b % 2 != 0:
    a.sort()
    c = int((len(a)-1)/2)
    x = int(a[c])
    print('%.1f'%x)
else:
    a.sort()
    d = int(len(a)/2)
    e = (a[d-1] + a[d])/2
    # y = int(e)
    print('%.1f'%e)

# chars = tuple(str(123))
# print(chars)