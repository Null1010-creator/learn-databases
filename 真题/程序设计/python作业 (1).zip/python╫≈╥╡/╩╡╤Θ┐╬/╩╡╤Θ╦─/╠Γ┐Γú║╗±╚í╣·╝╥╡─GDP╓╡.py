# 【问题描述】
# 存储国家GDP的字典结构如下：
# GDP = {'USA': 95,'China': 80,'Japan': 50}

# 题目要求：
# 1、请从标准输入录入多个国家的名字和对应的GDP，存入GDP字典中。(字典不为空)
# 2、获取所有的key值，存储在列表里
# 3、获取所有的value值，存储在列表里
# 4、判断 键'India' 是否在字典中
# 5、获得字典里所有value 的和

# 【样例输入】
# USA 95
# China 80
# Japan 50
# ok

# 【样例输出】
# ['China', 'Japan', 'USA']
# [50, 80, 95]
# no
# 225

# 【样例说明】
# 输入为多行，分别是以空格分隔开的国家和对应的GDP值，以"ok"结束
# 输出第一行：所有的key值，存储在列表里，升序排列
# 输出第二行：所有的value值，存储在列表里，升序排列
# 输出第三行：判断 键'India' 是否在字典中，是输出'yes',否输出'no'
# 输出第四CountryGDP行：字典里所有value 的和

CountryGDP={}
while True:
    iCountryiGDP = input()
    if iCountryiGDP == "ok":
        break
    iCountry,iGDP = iCountryiGDP.split(" ")
    CountryGDP[iCountry] = iGDP

Country = []
GDP = []

for k,v in CountryGDP.items():
    Country.append(k)
    GDP.append(int(v))
    Country.sort()
    GDP.sort()

print(Country)
print(GDP)

print("yes" if "India" in CountryGDP else "no")

isum = 0
for i in CountryGDP.values():
    isum += int(i)

print(isum)

