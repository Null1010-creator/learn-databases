# 【问题描述】
# 小王的最近几天的水果消费清单如下所示(若没有消费记录，输入为"None")，
# 每条记录的格式类似如下，以"None"结束，每条数据是水果名和消费额，空格隔开：

# apple 25.0
# pear 8.0
# apple 5.0
# pear 2.0
# banana 10.0
# orange 30.0
# None

# 题目要求：
# 1. 输出小王最近购买过哪些水果及其购买次数（整数）和总金额（保留两位小数）。
# （排序规则：先按购买金额降序，再按购买次数降序，都相同的话按水果名升序）


# 【样例输入】
# apple 25.0
# pear 8.0
# apple 5.0
# pear 2.0
# banana 10.0
# orange 30.0
# None

# 【样例输出】
# apple 2 30.00
# orange 1 30.00
# pear 2 10.00
# banana 1 10.00

# 【样例说明】
# 输入为不定行，以"None"结束，每条数据是水果名和消费额，空格隔开
# 输出为不定行，每行依次为：水果名、购买次数(整数)、总金额(保留两位小数)。
# （排序规则：先按购买金额降序，再按购买次数降序，都相同的话按水果名升序）

# --------------------------------------------------------------------

# 从标准输入录入信息，存储到字典CostInfo里，字典结构如下：
# {'apple': [2, 0.8], 'pear': [2, 10.0], 'b': [1, 10]} value为一个列表，存储购买次数和总金额

Fruit = []                                                 # 创建空列表用于储存 所有 [ [水果] ]
Fruit_Num_Comsumption = []                                 # 创建空列表用于储存 所有 [ [水果 , 购买次数 , 消费金额] ]
Fruit_Num_SumComsumption = []                               # 创建空列表用于储存 所有[ [水果 , 购买次数 , 消费金额] ]


#输入并储存数据
while True:
    iFruitComsumption = input()                             # 输入水果和对应消费金额

    if iFruitComsumption == "None":                         # 判断是否输入结束
        break                                               # 结束循环，即结束输入

    ifruit,icomsumption = iFruitComsumption.split()         # 将输入的水果及消费金额分开
    icomsumption = float(icomsumption)
    inum = 1

    ifruit_inum_icomsumption = [ifruit,inum,icomsumption]   # 创建空列表用于储存 某一种 [水果 , 购买次数 , 单次消费金额]
    Fruit_Num_Comsumption.append(ifruit_inum_icomsumption)
    Fruit.append(ifruit)

# print(Fruit)                                                # ['apple', 'pear', 'apple', 'pear', 'banana', 'orange']
# print(Fruit_Num_Comsumption)                                # [['apple', 1, 25.0], ['pear', 1, 8.0], ['apple', 1, 5.0], ['pear', 1, 2.0], ['banana', 1, 10.0], ['orange', 1, 30.0]]


#去掉重复元素
Fruit2 = set(Fruit)                                         # {'orange', 'banana', 'apple', 'pear'}
Fruit3 = list(Fruit2)                                       # ['orange', 'banana', 'apple', 'pear']


# 双重循环 将同一水果的购买次数和单次消费金额汇总
for i in range(len(Fruit3)):
    inum = 0
    iSumComsumption = 0
    for j in range(len(Fruit_Num_Comsumption)):
        if Fruit_Num_Comsumption[j][0] == Fruit3[i]:
            inum += 1
            iSumComsumption += Fruit_Num_Comsumption[j][2]
    iFruit_iNum_iSumComsumption = [Fruit3[i],inum,iSumComsumption]
    Fruit_Num_SumComsumption.append(iFruit_iNum_iSumComsumption)

# print(Fruit_Num_SumComsumption)                             # [['pear', 2, 10.0], ['apple', 2, 30.0], ['banana', 1, 10.0], ['orange', 1, 30.0]]


# 按购买金额降序
for i in range(len(Fruit_Num_SumComsumption)-1 ,0 ,-1):
    for j in range(0,i):
        if Fruit_Num_SumComsumption[j][2] < Fruit_Num_SumComsumption[j+1][2]:
            Fruit_Num_SumComsumption[j],Fruit_Num_SumComsumption[j+1] = Fruit_Num_SumComsumption[j+1],Fruit_Num_SumComsumption[j]


# 按购买次数降序
for i in range(len(Fruit_Num_SumComsumption)-1 ,0 ,-1):
    for j in range(0,i):
        if Fruit_Num_SumComsumption[j][2] == Fruit_Num_SumComsumption[j+1][2]:
            if Fruit_Num_SumComsumption[j][1] < Fruit_Num_SumComsumption[j+1][1]:
                Fruit_Num_SumComsumption[j],Fruit_Num_SumComsumption[j+1] = Fruit_Num_SumComsumption[j+1],Fruit_Num_SumComsumption[j]

# print(Fruit_Num_SumComsumption)                             # [['apple', 2, 30.0], ['orange', 1, 30.0], ['pear', 2, 10.0], ['banana', 1, 10.0]]

# 按水果名升序
for i in range(len(Fruit_Num_SumComsumption)-1 ,0 ,-1):
    for j in range(0,i):
        if Fruit_Num_SumComsumption[j][2] == Fruit_Num_SumComsumption[j+1][2]:
            if Fruit_Num_SumComsumption[j][1] == Fruit_Num_SumComsumption[j+1][1]:
                if Fruit_Num_SumComsumption[j][0] > Fruit_Num_SumComsumption[j+1][0]:
                    Fruit_Num_SumComsumption[j],Fruit_Num_SumComsumption[j+1] = Fruit_Num_SumComsumption[j+1],Fruit_Num_SumComsumption[j]

for x in Fruit_Num_SumComsumption:
    print(x[0],x[1],"%.2f" % x[2])

# 样例输出
# apple 2 30.00
# orange 1 30.00
# pear 2 10.00
# banana 1 10.00