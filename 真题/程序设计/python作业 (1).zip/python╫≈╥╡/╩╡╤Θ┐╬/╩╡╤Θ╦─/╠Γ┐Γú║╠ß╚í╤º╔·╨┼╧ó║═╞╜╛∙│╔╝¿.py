# 录入学生的基本信息，取得学生的姓名、性别和平均成绩（科目数量不确定,但至少有一项）
# 【样例输入】'2001001','Zhang San','male',65,False,[76,90,85]
student = eval(input())
info = student[1],student[2]
avg = sum(student[-1])/len(student[-1])
print(info)
print("%.2f"%avg)