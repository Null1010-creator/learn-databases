# 有一个分数数列：2/1,3/2,5/3,8/5,13/8,21/13,...,从键盘输入一个正整数n，求出这个数列的前n项之和。并保留四位小数。

n = eval(input())
a = [1,2]
i = 2
while i <= n:
        b = a[-2] + a[-1]
        a.append(b)
        i += 1
c = []
x = 0
while x <= len(a) - 2:
    d = a[x+1]/a[x]
    c.append(d)
    x += 1
e = sum(c)
print('%.4f'%e)
# print(c)


# 斐波那契数列(输出前n个斐波那契数列数)
# n = eval(input())
# a = [1,1]
# i = 3
# if type(n) == int:
#     if n == 1:
#         print('1')
#     else:
#         while i <= n:
#             b = a[-2] + a[-1]
#             a.append(b)
#             i += 1
#         for x in a:
#             print(x,end=' ')
# else:
#     print('illegal input')