# 输入两个列表，一个为存放姓名，一个存放年龄，
# 另定义一列表，该列表存放的元素为元组：（姓名，年龄），姓名和年龄数值为输入的两个列表对应位置的内容。
# 分两行输入，第一行输入姓名，按照字符串的方式输入，多个姓名之间用逗号分隔。第二行输入成绩，包含方括号，元素之间用英文逗号分隔。
Name = eval(input())
Age = eval(input())

NameAge = []

for i in range (len(Name)):
    NA = Name[i],Age[i]
    NameAge.append(tuple(NA))
    # NameAge[i] =  tuple(Name[i],Age[i])

# print(ti)

print(NameAge)

# print(Name,type(Name))