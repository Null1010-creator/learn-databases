# 编写程序，从键盘输入一个数n，输出n以内的所有的回文素数。若n输入不合法（为小数或者负数），则输出提示：“illegal input”。
# 回文素数是指一个数既是素数又是回文数。一个大于1的自然数，除了1和它自身外，不能被其他自然数整除的数称之为素数。
# 例如131既是素数又是回文数。

# n = eval(input())
# lst = []
# if type(n) == float:
#     print('illegal input')
# elif n <= 0:
#     print('illegal input')
# else:
#     for i in range(1,n+1):
#         a = str(i)
#         for x in range(len(a)):
#             if(a[x] == a[-(x+1)]):
#                 r = 0
#             else:
#                 r = 1
#         if r == 0:
#             k = 2
#             while k <= int(a)-1:
#                 b = int(a) % k
#                 if b == 0:
#                     break
#                 else:
#                     k += 1
#             if k == int(a):
#                 lst.append(int(a))
# print(" ".join(str(i) for i in lst))

# 函数
def sushu(n):
    if n >= 2 and type (n) == int:
        for i in range(2,n//2+1):
            if n % i == 0:
                return False
        return True
    else:
        return False
def huiwenshu(n):
    if str(n) == str(n)[::-1]:
        return True
    else:
        return False
n = eval(input())
if n < 2 or type(n) != type(1):
    print("illegal input")
else:
    for i in range(2,n):
        if sushu(i) and huiwenshu(i):
            print(i,end=' ')