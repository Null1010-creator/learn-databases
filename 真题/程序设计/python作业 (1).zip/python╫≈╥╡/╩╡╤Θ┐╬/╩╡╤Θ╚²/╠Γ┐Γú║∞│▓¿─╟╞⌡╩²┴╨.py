# 斐波那契数列（Fibonacci sequence），又称黄金分割数列，
# 因数学家列昂纳多·斐波那契（Leonardoda Fibonacci）以兔子繁殖为例子而引入，故又称为“兔子数列”。
# 数学上，斐波那契数列以递归的形式进行定义：n=1时，F(1)=1;n=2时，F(2)=1;当n>2时，F(n)=F(n-1)+F(n-2)。
# 即除了前两项以外，后面的每一项都是前面相邻两项的和。请根据这个定义进行编程，输出前n个斐波那契数列数。

n = eval(input())
a = [1,1]
i = 3
if n <= 0:
    print('illegal input')
elif type(n) == int:
    if n == 1:
        print('1')
    else:
        while i <= n:
            b = a[-2] + a[-1]
            a.append(b)
            i += 1
        for x in a:
            print(x,end=' ')
else:
    print('illegal input')

