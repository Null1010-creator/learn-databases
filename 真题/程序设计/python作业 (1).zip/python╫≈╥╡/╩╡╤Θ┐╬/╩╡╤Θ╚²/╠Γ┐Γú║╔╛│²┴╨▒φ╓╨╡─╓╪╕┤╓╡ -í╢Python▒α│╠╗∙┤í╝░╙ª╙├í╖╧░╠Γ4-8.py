# 输入一个列表，删除其中的重复值，再输出。
# 要求：假设列表中存在k个值为a的元素，删除前k-1个元素，保留最后一个。 不同元素在列表中的相对位置不应被改变。

Old = eval(input())
New = []

# t = Old[-1]

for i in range(len(Old)-1,0,-1):
    t = Old[i]
    if t not in New:
        New.append(t)

New.reverse()

print(New)

# for i in range(9,1,-1):
#     print (i)

# 倒序处理，用一个空列表处理，倒着遍历整个列表，用空列表存储第一次遇到的值，
# 判断标准：如果这个值不在这个列表里面，那就是第一次遇到的，那就加到这个列表里面