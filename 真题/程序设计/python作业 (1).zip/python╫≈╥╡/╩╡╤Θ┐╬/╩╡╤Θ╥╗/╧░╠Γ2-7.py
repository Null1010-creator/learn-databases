iWlx= "My favorite sports are as follows:\n\tfootball\n\ttable tennis\n\tbadminton\n\tswimming\nrunning"
print(iWlx)