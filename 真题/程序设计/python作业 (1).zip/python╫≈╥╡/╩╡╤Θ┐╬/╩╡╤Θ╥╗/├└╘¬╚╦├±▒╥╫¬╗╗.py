Money = input()
if Money[0] in ['&']:
    C = (eval(Money[1:]))/6.78
    print("$""%.2f"%C)
elif Money[0:3] in ['RMB']:
    D = (eval(Money[3:]))/6.78
    print("USD""%.2f"%D)
elif Money[0] in ['$']:
    A = 6.78*eval(Money[1:])
    print("&""%.2f"%A)
elif Money[0:3] in ['USD']:
    B = 6.78*eval(Money[3:])
    print("RMB""%.2f"%B)
else:
    print("Error")