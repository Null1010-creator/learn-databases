Money = input()
if Money[-1] in ['&','RMB']:
    C = (eval(Money[0:-1]))/6.78
    print("%.2fC"%C)
elif Money[-1] in ['$','USD']:
    A = 6.78*eval(Money[0:-1])
    print("%.2fA"%A)
else:
    print("Error")