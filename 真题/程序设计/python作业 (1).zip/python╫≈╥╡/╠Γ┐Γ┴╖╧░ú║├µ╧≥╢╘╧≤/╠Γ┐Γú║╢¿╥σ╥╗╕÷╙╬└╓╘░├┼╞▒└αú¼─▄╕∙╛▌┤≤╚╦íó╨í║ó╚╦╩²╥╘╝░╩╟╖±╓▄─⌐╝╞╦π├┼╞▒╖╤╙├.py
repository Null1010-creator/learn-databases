# 【问题描述】
# 按照以下要求定义一个游乐园门票类，并创建实例调用函数，完成儿童和大人的总票价统计（人数不定，由用户输入）
# 1)平日票价100元
# 2)周末票价为平日票价120%
# 3)儿童半价

# 【输入形式】逗号分割输入成年人人数,小孩人数以及购票日期，购票日期用年月日用"-"分开.
# 【输出形式】输出成年人人数,小孩人数，购票日期以及总费用

# 【样例输入】1,2,2021-02-23
# 【样例输出】adult:1,child:2,isWeekend:False,total cost:200.0

# 【样例说明】逗号分割输入成年人人数,小孩人数以及购票日期，购票日期用年月日用"-"分开.


import datetime

class Ticket:
    def __init__(self,weekend=False,child=False):
        self.exp = 100
        if weekend:
            self.exp = 1.2 * self.exp
        if child:
            self.exp = 0.5 * self.exp
    def calcPrice(self,num):
        P = self.exp * num
        return P

s = input().split(',')
m,n = int(s[0]),int(s[1])
day = datetime.datetime.strptime(s[2],"%Y-%m-%d")
if day.weekday() == 5 or day.weekday() == 6:
    adult = Ticket(weekend = True)
    child = Ticket(weekend = True,child = True)
    isWeekend = True
else:
    adult = Ticket()
    child = Ticket(child = True)
    isWeekend = False

print("adult:{},child:{},isWeekend:{},total cost:{}".format(m,n,isWeekend,adult.calcPrice(m) + child.calcPrice(n)))