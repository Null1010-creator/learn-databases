# 【问题描述】
# 创建student类，设置实例属性：学号，姓名，年龄及程序设计成绩，增加类属性：学生人数（count）和所有学生成绩总和
# （sum），定义类方法，用于显示所有学生的平均成绩。

# 【输入形式】每行输入学号，姓名，年龄及成绩，结束用字符串"End"
# 【输出形式】输出班级人数及平均成绩

# 【样例输入】
# 20200101,zhangsan,18,95
# End
# 【样例输出】
# stuCount:1,scoreAve:95.0

# 【样例说明】可输入多条学生的学号，姓名，年龄及成绩信息，结束时另起一行用"End"结束。


class Student:
    count = 0
    sum = 0

    def __init__(self,sno,sname,sage,score):
        self.sno = sno
        self.sname = sname
        self.sage = sage
        self.score = score
        Student.count = Student.count + 1
        Student.sum = Student.sum + int(score)

    def showAverageScore():
        if Student.count != 0:
            print("stuCount:{},scoreAve:{}".format(Student.count, Student.sum/Student.count))
        else:
            print("stuCount:{},scoreAve:{}".format(Student.count, "None"))

while True:
    stext = input()
    if stext == "End":
        break
    s = stext.split(",")
    stu = Student(s[0],s[1],s[2],s[3])
Student.showAverageScore()