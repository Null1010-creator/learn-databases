# 【问题描述】
# 设计一个购房商贷月供计算器类，采用等额本息还款法，每月还款金额和总利息计算公式如下：
# 每月月供额=(贷款本金×月利率×(1＋月利率)＾还款月数)÷((1＋月利率)＾还款月数-1)
# 总利息=还款月数×每月月供额-贷款本金

# 【输入形式】逗号分割分别输入贷款金额，年利率和贷款年限，年利率按实际利率的100倍录入
# 【输出形式】输出月供和总利息

# 【样例输入】1000000,5.3,30
# 【样例输出】monthly_payment: 5553.05, Total interest: 999096.75

# 【样例说明】年利率按实际利率的100倍录入，例如：5.3%则录入5.3

a,b,c = input().split(",")
a = int(a)
b = float(b)/1200
c = int(c)
d = (1 + b) ** (c * 12)
monthly_payment = (a * b * d) / (d-1)
Total_interest = c * 12 * monthly_payment - a
print('monthly_payment: ','%.2f'%monthly_payment,',',' Total interest: ','%.2f'%Total_interest,sep='')
# print(d)