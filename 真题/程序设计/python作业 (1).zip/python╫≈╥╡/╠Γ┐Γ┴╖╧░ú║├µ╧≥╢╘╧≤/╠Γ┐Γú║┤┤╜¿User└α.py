# 【问题描述】
# 创建一个名为User 的类，包含first_name 、last_name 、tel及place共4个属性。在类User 中定义一个名为describe_user() 的方法，用于打印用户信息摘要；

# 【输入形式】以逗号分隔符分别输入用户的last_name，first_name，tel及place
# 【输出形式】输出用户的电话及地址

# 【样例输入】li,si,13012300001,ChongQing
# 【样例输出】lisi tel:13012300001,place:ChongQing

# 【样例说明】输出用户的个人信息



class User:
    def __init__(self,first_name,last_name,tel,place):
        #完成成员变量的赋值
        self.first_name = first_name
        self.last_name = last_name
        self.tel = tel
        self.place = place

    def describe_user(self):
        print(self.first_name + self.last_name + "tel:{},place:{}".format(self.tel,self.place))

s = input().split(",")
u1 = User(s[0],s[1],s[2],s[3])
u1.describe_user()