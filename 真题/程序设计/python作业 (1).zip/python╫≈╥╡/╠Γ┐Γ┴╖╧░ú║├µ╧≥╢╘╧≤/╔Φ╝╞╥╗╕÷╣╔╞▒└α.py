# 【问题描述】
# 设计一个名为Stock的类来表示一个公司的股票，包括以下内容：
# 1）股票代码、股票名称、前一天股票价格、当天股票价格4个私有属性；
# 2）构造方法，需初始化代码、名称、前一天价格和当天价格等属性；
# 3）返回股票名字的get方法;
# 4）返回股票代码的get方法;
# 5）获取和设置股票前一天价格的get和set方法;
# 6）获取和设置股票当前价格的get和set方法;
# 7）名为getChangePercent()方法，返回前日收市价至当前价格的变化百分比；
# 8) 包括文档字符串，其内容为:"Stock Information Class"

# 说明：各方法的名称及参数要求请参见测试程序。

# 【样例输入】
# 601318
# Chinese PINAN
# 63.21
# 64.39

# 【样例输出】
# Code:601318
# Name:Chinese PINAN
# Price/Yesterday:63.21
# Price/Today:64.39
# Edit Price/Yesterday To:50.25
# Price Change Percentage:28.14%
# Stock Information Class


#class  Stock
class Stock:
    "Stock Information Class"
    def __init__(self,sCode,sName,priceYesterday,priceToday):
        self.__sCode = sCode
        self.__sName = sName
        self.__priceYesterday = priceYesterday
        self.__priceToday = priceToday
    
    def getCode(self):
        return self.__sCode

    def getName(self):
        return self.__sName

    def getPriceYesterday(self):
        return self.__priceYesterday

    def getPriceToday(self):
        return self.__priceToday

    def setPriceYesterday(self,PriceYesterday):
        self.__priceYesterday = PriceYesterday

    def getChangePercent(self):
        # self.priceYesterday = Stock.setPriceYesterday()
        return (self.__priceToday - self.__priceYesterday) / self.__priceYesterday

sCode  =  input()  #Stock  Code
sName  =  input()  #Stock  Name
priceYesterday  =  float(input())    #Price/Yesterday
priceToday  =  float(input())    #Price  Today
s  =  Stock(sCode,sName,priceYesterday,priceToday)
print("Code:",s.getCode())
print("Name:",s.getName())
print("Price/Yesterday:%.2f\nPrice  Today:%.2f"  %  (s.getPriceYesterday(),s.getPriceToday()))
s.setPriceYesterday(50.25)
print("Edit  Price/Yesterday  To:%.2f"  %  50.25)
print("Price  Change  Percentage:%.2f%%"  %  (s.getChangePercent()*100))
print(Stock.__doc__)



# class Stock:
#     """Stock Information Class"""

#     def __init__(self, sc, sn, py, pt):
#         self.__sCode = sc
#         self.__sName = sn
#         self.__priceYesterday = py
#         self.__priceToday = pt

#     def getName(self):
#         return self.__sName

#     def getCode(self):
#         return self.__sCode

#     def setPriceYesterday(self, py):
#         self.__priceYesterday = py

#     def getPriceYesterday(self):
#         return self.__priceYesterday

#     def setPriceToday(self, pt):
#         self.__priceToday = pt

#     def getPriceToday(self):
#         return self.__priceToday

#     def getChangePercent(self):
#         return (self.__priceToday - self.__priceYesterday) / self.__priceYesterday

# sCode = input() #输入代码
# sName = input() #输入名称
# priceYesterday = float(input())  #输入昨日价格
# priceToday = float(input())  #输入今日价格
# s = Stock(sCode,sName,priceYesterday,priceToday)
# print("代码:",s.getCode())
# print("名称:",s.getName())
# print("昨日价格:%.2f\n今天价格:%.2f" % (s.getPriceYesterday(),s.getPriceToday()))
# s.setPriceYesterday(50.25)
# print("修正昨日价格为:%.2f" % 50.25)
# print("价格变化百分比:%.2f%%" % (s.getChangePercent()*100))
# print(Stock.__doc__)