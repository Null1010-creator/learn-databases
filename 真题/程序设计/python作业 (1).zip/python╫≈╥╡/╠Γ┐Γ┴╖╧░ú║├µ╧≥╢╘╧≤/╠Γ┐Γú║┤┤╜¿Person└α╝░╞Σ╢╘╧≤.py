# 【问题描述】
# 创建Person类，包含count属性和show方法；创建Person类对象p1,调用p1的show方法完成输出；

# 【输入形式】
# 输入变量name；
# 【输出形式】
# 输出方法执行结果；

# 【样例输出】
# zhangsan test!!!
# 【样例说明】
# 根据不同的输入参数输出对应的结果



#创建Person类
class Person:
    count = 0
    
    def show(self,name):
        self.name = name
        print(self.name,"test!!!")

p1 = Person()
#输入name变量
name = input()
print(p1.count)
#调用show方法完成输出
p1.show(name)

