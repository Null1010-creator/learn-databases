# 【问题描述】
# 设计一个类Root来计算ax2+bx+c=0的根。
# 该类包括：a、b、c共3个属性表示方程的3个系数，getDiscriminant()方法返回b2-4ac, getRoot1()和getRoot2()返回方程的两个根
# 用求根公式

from math import *

class Root:
    def __init__(self,a,b,c):   #构造函数
        self.a = a
        self.b = b
        self.c = c
    
    def getDiscriminant(self):
        return self.b**2-4*self.a*self.c
    
    def getRoot1(self):
        x1 = ( -self.b + (b**2-4*a*c)**0.5 )/(2*a)
        return x1

    def getRoot2(self):
        x2 = ( -b - (b**2-4*a*c)**0.5 )/(2*a)
        return x2

a = float(input())  
b = float(input())  
c = float(input())  

root = Root(a,b,c)
if root.getDiscriminant() > 0:
    print("{:.2f}".format(root.getRoot1()))
    print("{:.2f}".format(root.getRoot2()))
elif root.getDiscriminant() == 0:
    print("{:.2f}".format(root.getRoot1()))
else:
    print("No  Root!")
