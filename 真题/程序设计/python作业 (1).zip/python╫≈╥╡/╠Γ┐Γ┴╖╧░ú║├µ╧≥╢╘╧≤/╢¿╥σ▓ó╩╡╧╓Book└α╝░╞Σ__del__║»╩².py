# 【问题描述】
# 图书馆里有很多的书， 请定义一个名为Book的类。
# 该类的属性包括书名（字符串），书号（字符串），单价（浮点数）；该类的构造函数接受书名，书号及单价三个参数并参成对象初始化；
# 该类的__del__()函数则向终端打印如下信息：
# Book destroyed-书名,书号,单价
# 注意：单价保留两位小数。

# 【样例输入】
# Python Programming
# 888-999
# 43.678
# 【样例输出】
# Book destroyed-Python Programming,888-999,43.68



class Book:

    def __init__(self,sName,sNo,fPrice):
        self.sName = sName
        self.sNo = sNo
        self.fPrice = fPrice
        print('Book destroyed-{},{},{:.2f}'.format(sName,sNo,fPrice))

sName = input()    #Input  Book  Name
sNo = input()  #Input  Book  Number
fPrice = float(input())      #Input  Book  Price
b = Book(sName,sNo,fPrice)
b = None      #__del__  method  of  object  b  been  triggered  