# 设计下述BMI类，用于计算身体质量指数。该指数等于体重（kg)除以身高(米)的平方。
# name: str
# age: int
# height: float
# Weight: float

# getBMI(): float
# getStatus(): str

# 相应的判定标准如下所示:
# BMI < 18   -->   underweight 
# 18 <= BMI < 25 --> idea
# 25 <= BMI < 27  --> overweight
# 27 <= BMI    --> obesity

# 其中，name为姓名，age为年龄，height为身高，单位为米，weight为体重，单位为kg。
# getBMI()函数返应计算所得的身体质量指数；
# getStatus()返回评价结果，其值应为underweight/ideal/overweight/obesity之一。


# 【样例输入】
# Alex
# 27
# 1.75
# 68
# 【样例输出】
# Name: Alex
# Age: 27
# BMI = 22.204
# Result = ideal



class BMI:
    def __init__(self,name,age,height,weight):
        self.name = name
        self.age = age
        self.height = height
        self.weight = weight
    
    def getBMI(self):
        x = self.weight / self.height ** 2
        return x

    def getStatus(self):
        if self.getBMI() < 18:
            return 'underweight'
        elif 18 <= self.getBMI() < 25:
            return 'idea'
        elif 25 <= self.getBMI() < 27:
            return 'overweight'
        else:
            return 'obesity'



sName = input()    
iAge = int(input())
fHeight = eval(input())  #in  meter
fWeight = eval(input())  #in  kg
bmi=BMI(sName,iAge,fHeight,fWeight)
print("Name:",bmi.name)
print("Age:",bmi.age)
print("BMI  =  %.3f"  %  bmi.getBMI())
print("Result  =",bmi.getStatus())