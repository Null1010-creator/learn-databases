# 【问题描述】
# 定义一个学生类
# 1.有下面的类属性：姓名 年龄 成绩（语文，数学，英语)[每课成绩的类型为整数]
# 2.类方法
# 1） 获取学生的姓名：get_name() 返回类型:str
# 2 ）获取学生的年龄：get_age() 返回类型:int
# 3 ）返回3门科目中最高的分数：get_course() 返回类型:int

# 【输入形式】输入姓名，年龄及三门成绩
# 【输出形式】输出姓名，年龄及三门成绩中最高成绩

# 【样例输入】
# 张三,20,69,83,71
# 【样例输出】
# name: zs
# age: 20
# max_score: 83

# 【样例说明】以逗号分割输入姓名，年龄及成绩


class student:

    def __init__(self,sname,sage,sChinese,sMath,sEnglish):
        self.sname = sname
        self.sage = sage
        self.sChinese = sChinese
        self.sMath = sMath
        self.sEnglish = sEnglish

    def get_name(self):
        return str(self.sname)

    def get_age(self):
        return int(self.sage)

    def get_course(self):
        return max(self.sChinese,self.sMath,self.sEnglish)

a = input()
sname,sage,sChinese,sMath,sEnglish = a.split(',')
Student = student(sname,sage,sChinese,sMath,sEnglish)
print("name: {}".format(Student.get_name()))
print("age: {}".format(Student.get_age()))
print("max_score: {}".format(Student.get_course()))