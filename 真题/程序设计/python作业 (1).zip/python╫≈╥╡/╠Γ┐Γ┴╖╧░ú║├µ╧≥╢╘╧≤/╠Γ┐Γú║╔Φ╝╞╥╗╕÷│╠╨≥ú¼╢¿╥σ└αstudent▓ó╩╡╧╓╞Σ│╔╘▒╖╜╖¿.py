# 【问题描述】
# 设计一个程序，定义类student和它的实例属性（学号，姓名，年龄和Python程序设计成绩），重写构造函数，
# 可以初始化学生的学号、姓名、年龄和成绩；定义show方法，可以显示某个学生的所有实例属性。

# 【输入形式】以逗号分隔符分别输入学号，姓名，年龄及成绩
# 【输出形式】输出该对象的学号，姓名，年龄及成绩信息

# 【样例输入】20200101,zhangsan,21,87
# 【样例输出】sname:zhangsan,sno:20200101,sage:21,score:87

# 【样例说明】输入学生的学号，姓名，年龄及成绩等信息

class student:

    def __init__(self,sname,sno,sage,score):
        self.sname = sname
        self.sno = sno
        self.sage = sage
        self.score = score

stext = input()
sno,sname,sage,score = stext.split(",")
Student = student(sname,sno,sage,score)
print("sname:{},sno:{},sage:{},score:{}".format(Student.sname,Student.sno,Student.sage,Student.score))