# 【问题描述】定义名为Number的类，其中有两个整型数据成员n1和n2，应声明为私有。
# 编写__init__方法，外部接收n1和n2，再为该类定义加（addition）、减（subtration）等成员方法，分别对两个成员变量执行加、减、乘、除的运算。
# 创建Number类的对象，调用各个方法，并显示计算结果。

# 【输入形式】以逗号分割输入两个数及运算符；
# 【输出形式】运算符add表示加，sub表示减，其他的运算符输出字符串"error!"。

# 【样例输入】1,2,add
# 【样例输出】1+2=3

# 【样例说明】输入1和2两个整数数，实现相加



class Number():
    def  __init__(self,n1,n2):
        self.__n1 = n1
        self.__n2 = n2
        
    def addition(self):
        m1 = self.__n1 + self.__n2
        print('%d+%d=%d'%(self.__n1,self.__n2,m1))
        
    def subtration(self):
        m2 = self.__n1 - self.__n2
        print('%d-%d=%d'%(self.__n1,self.__n2,m2))

n1,n2,op = input().split(",")
mm = Number(int(n1),int(n2))

if op == 'add':
    mm.addition()
elif op == 'sub':
    mm.subtration()
else:
    print("error!")