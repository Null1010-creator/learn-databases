nums1 = eval(input())
nums2 = eval(input())
nums1.sort()
nums1.sort()
arr = []
i = j = 0
while i < len(nums1) and j < len(nums2):
    if nums1[i] < nums2[j]:
        i += 1
    elif nums1 [i] > nums2[j]:
        j += 1
    else:
        arr.append(nums1[i])
        i += 1
        j += 1
for x in arr:
    while arr.count(x) > 1:
        arr.sort()

print(arr)

# a = [1,2,3]
# b = [3,2,4,5]

# # a =eval(input())
# # b= eval(input())
# c = a+b
# d = set(c)
# e = list(d)
# for i in e:
#     if c.count(i) > 1:
#         print(i)