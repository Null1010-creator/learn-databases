# s = 0
# a = input()
# for x in a:
#     s =s+int(x)
# print(s)

# sum = 0
# for i in list:
#     sum+=int ()

L = eval(input())
A = sum(L)
B = A/len(L)
print('%.2f'%B)
# print(L,type(L))