a = list(eval(input()))
n,m = eval(input())
if n+1 <= len(a):
    c = []
    d = list(c)
    e = a[n]
    i =1
    while i<=m:
        d.append(e)
        i = i+1
    g = a+d
    print(g)
else:
    print("error")