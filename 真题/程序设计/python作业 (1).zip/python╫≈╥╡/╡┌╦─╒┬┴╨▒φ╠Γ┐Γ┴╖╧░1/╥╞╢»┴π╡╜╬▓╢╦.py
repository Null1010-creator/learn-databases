nums = eval(input())
nums2 = []
for x in range(len(nums)-1,-1,-1):
  if nums[x]==0:
      nums.remove(0)
      nums2.append(0)
print(nums+nums2)