a = eval(input())
b,c = eval(input())
if b==c:
    print(a)
elif b>c:
    if b<len(a):
        del a[c+1:b+1]
        print(a)
    else:
        print("error")
elif b<c:
    if c<len(a):
        del a[b:c]
        print(a)
    else:
        print("error")
else:
    print("error")

# # 方法一：
# l = eval(input())
# n,m = eval(input())
# if n>len(l)-1 or m>len(l)-1:
#     print("error")
# else:
#     if n>m:
#         n,m = m,n
#         del l[n+1:m+1]
#         print(l)
#     else:
#         del l[n:m]
#         print(l)


# # 方法二：
# l = eval(input())
# n,m = eval(input())
# if n>len(l)-1 or m>len(l)-1:
#     print("error")
# else:
#     if n>m:
#         del l[n:m:-1]
#         print(l)
#     else:
#         del l[n:m]
#         print(l)