a = eval(input())
b =[]
for i in a:
    if i==0:
        b.append(0)
        a.remove(0)
print(a+b)