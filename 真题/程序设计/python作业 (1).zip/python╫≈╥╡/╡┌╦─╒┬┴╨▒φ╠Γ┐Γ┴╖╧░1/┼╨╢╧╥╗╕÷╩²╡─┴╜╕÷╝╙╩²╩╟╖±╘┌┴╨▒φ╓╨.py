nums = eval(input())
n = eval(input())
for x in nums:
    if (n-nums[x]) in nums :
            print(True)
            break
else:
    print(False)