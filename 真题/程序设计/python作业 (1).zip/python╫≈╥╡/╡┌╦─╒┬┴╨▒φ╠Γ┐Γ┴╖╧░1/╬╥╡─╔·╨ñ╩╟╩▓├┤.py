import io

import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')

def myZodiac(year):
    zod = ['猴','鸡','狗','猪','鼠','牛','虎','兔','龙','蛇','马','羊']
    idx = year%12
    return zod[idx]

def main():
    y = eval(input())
    print(myZodiac(y))

main()

# zodiac = ['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪']
# print (type(zodiac))
# print (zodiac[3])