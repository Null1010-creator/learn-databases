a = eval(input())
c  = 0
for i in range(1,a + 1):
    b = 1
    x = 1
    while x <= i:
        b = b * x
        x += 1
    c = c + 1 / b 
c  = c + 1
print('%.10f'%c)