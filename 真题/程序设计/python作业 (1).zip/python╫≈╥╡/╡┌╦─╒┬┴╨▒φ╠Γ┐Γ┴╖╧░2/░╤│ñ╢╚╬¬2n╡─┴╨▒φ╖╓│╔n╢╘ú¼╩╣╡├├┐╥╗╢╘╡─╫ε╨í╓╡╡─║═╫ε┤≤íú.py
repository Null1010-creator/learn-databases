# 给定长度为2n的自然数列表nums，把这些数分成n对，把每一对的最小值加起来（不同的分法，其和可能不同），输出最小值和的最大值。

def maxsum(nums):
    b = []
    nums.sort()
    for i in range(len(nums)):
        if i%2 == 0:
            b.append(nums[i])
    c = sum(b)
    return c

nums  =  eval(input())
v  =  maxsum(nums)#调用自定义函数
print(v)