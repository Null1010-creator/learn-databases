# 已知一个列表存放学生姓名，另外一个列表存放学生成绩。把姓名和成绩配对后，形成一个嵌套列表，按照成绩升序输出列表。

Name = list(input().split(","))
Grade = eval(input())
NameGrade = []
for i in range (len(Name)):
    NA = Name[i],Grade[i]
    NameGrade.append(list(NA))
Grade = list(Grade)
Grade.sort()
a = []
for i in NameGrade:
    if i[1] == Grade[0]:
        a.append(i)
for x in NameGrade:
    if x[1] == Grade[1]:
        a.append(x)
for y in NameGrade:
    if y[1] == Grade[2]:
        a.append(y)
print(a)