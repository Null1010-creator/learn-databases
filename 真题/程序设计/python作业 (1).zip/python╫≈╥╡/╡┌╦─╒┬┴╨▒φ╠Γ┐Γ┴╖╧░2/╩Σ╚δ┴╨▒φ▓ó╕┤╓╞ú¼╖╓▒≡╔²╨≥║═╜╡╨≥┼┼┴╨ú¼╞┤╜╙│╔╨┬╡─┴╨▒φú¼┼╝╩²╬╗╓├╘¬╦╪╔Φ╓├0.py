# 输入一个列表，长度大于2，复制列表，原始列表升序排列，复制列表降序排列。
# 把两个列表拼接成一个新的列表。原始列表在前。最后把偶数位置的元素设置为0，输出新列表。

l1 = eval(input())
#  拷贝列表
l2 = l1.copy()
l1.sort()
l2.sort(reverse=True)
l3  =  l1  +  l2
#  把偶数位置的元素设置为0
for i in range(len(l3)-1):
    if i % 2 == 0:
         l3[i] = 0
print(l3)