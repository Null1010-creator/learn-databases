# 读入一个大小为n的列表，找出其中的多数元素。
# 多数元素是指在列表中出现次数大于n//2的元素（每个列表最多一个多数元素）。根据代码框架编写一个函数。
# 如果有多数元素，输出这个元素的值，如果没有多数元素，输出False

def search(nums):
    a = len(nums)
    for i in nums:
        b = nums.count(i)
        if b > a/2:
            return i
        else:
            return('False')


nums  =  eval(input())
y  =  search(nums)
print(y)