a = eval(input())
a.sort()
if a == [0,0,0]:
    print(0)
else:
    b = str(a[-1])
    i = -2
    while i >= 0-len(a):
        b = b + str(a[i])
        i = i - 1
    print(b)