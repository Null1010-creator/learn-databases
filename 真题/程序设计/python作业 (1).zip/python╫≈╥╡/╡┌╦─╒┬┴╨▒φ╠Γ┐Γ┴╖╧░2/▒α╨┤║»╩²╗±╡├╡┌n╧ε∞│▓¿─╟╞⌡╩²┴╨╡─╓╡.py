# 编写函数获得第n项斐波那契数列的值。斐波那契数列前10项如下：[1, 1, 2, 3, 5, 8, 13, 21, 34, 55]。
# 第1项为1，第二项为1，从第三项开始，每一项等于前两项之和。

def Fibonacci(num,  n):
    i = 3
    while i <=n:
        a = num[-2] + num[-1]
        i += 1
        num.append(a)
    c = num[n-1]
    return(c)

num  =  [1,  1]
n  =  int(input())
print(Fibonacci(num,  n))
