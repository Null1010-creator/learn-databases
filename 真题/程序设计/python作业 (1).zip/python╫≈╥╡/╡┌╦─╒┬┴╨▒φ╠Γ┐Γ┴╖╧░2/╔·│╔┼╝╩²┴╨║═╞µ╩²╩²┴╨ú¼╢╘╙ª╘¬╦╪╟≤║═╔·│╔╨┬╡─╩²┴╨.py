# 输入一个正整数n，分别生成由n个连续偶数构成的偶数数列和n个连续奇数构成的奇数数列，
# 其中偶数数列的元素从0开始，奇数数列的元素从1开始。把这个两个数列对应位置的元素求和存入列表中并打印输出结果列表。

n  =  eval(input())
even  =  0  +  n  *  2
odd  =  1  +  n  *  2
l1  =  [x  for  x  in  range(0,even,2)]
l2  =  [x  for  x  in  range(1,odd,2)]
l3  =  []
for  y  in  range(len(l1)):
        l3.append(l1[y]+l2[y])
print(l3)