# sName=input().split()
# sGrade=eval(input())
# lst=[x+y for x in sName for y in sGrade]
# print(lst)

sName=input().split()
sName1 = list(sName)
sGrade=eval(input())
for i in range(len(sName1)):
    x = sName1[i-1]
    y = sGrade[i-1]
    print(x,y)
print(sName1)


# lst=[x+str(y) for x in sName1 for y in sGrade]
# print(lst)