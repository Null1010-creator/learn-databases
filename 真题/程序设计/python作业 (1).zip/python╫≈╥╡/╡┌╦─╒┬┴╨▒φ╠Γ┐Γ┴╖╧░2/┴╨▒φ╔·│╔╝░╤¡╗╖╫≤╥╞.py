n = eval(input())
x = range(1,n+1)
y = list(x)
a = y[0]
y.append(a)
del y[0]
print(y)