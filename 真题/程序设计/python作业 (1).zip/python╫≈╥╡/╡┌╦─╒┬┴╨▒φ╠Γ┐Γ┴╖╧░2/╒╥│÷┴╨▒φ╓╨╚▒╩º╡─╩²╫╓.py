#  读入一个长度为n-1的整数列表，这个列表的所有元素都是按照递增顺序排列，且每个数字都是唯一的，每个数字都在范围0~n-1之内。
#  0~n-1范围内的n个数字中有且只有一个数字不在该列表中。请找出这个数字。

def missNumber(nums):
    a = len(nums)
    b = a + 1
    c = list(range(b))
    for i in nums:
         c.remove(i)
    d = c[0]
    return(d)

nums  =  eval(input())
number  =  missNumber(nums)
print(number)